/**
 * Phase 0 Payload-First Security TDD Specification for FRIENDZONE Firestore Rules.
 * Documents and verifies the 12 adversarial ("Dirty Dozen") security assertions.
 */

export interface DirtyDozenCase {
  id: number;
  name: string;
  actorUid: string | null;
  emailVerified: boolean;
  operation: 'get' | 'list' | 'create' | 'update' | 'delete';
  path: string;
  payload?: Record<string, unknown>;
  expected: 'PERMISSION_DENIED';
}

export const DIRTY_DOZEN_PAYLOADS: DirtyDozenCase[] = [
  {
    id: 1,
    name: 'Unauthenticated profile creation',
    actorUid: null,
    emailVerified: false,
    operation: 'create',
    path: '/users/attacker',
    payload: { uid: 'attacker', displayName: 'Mallory' },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 2,
    name: 'Profile impersonation across UIDs',
    actorUid: 'userA',
    emailVerified: true,
    operation: 'update',
    path: '/users/userB',
    payload: { displayName: 'Hijacked' },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 3,
    name: 'Shadow field & self-unblock escalation',
    actorUid: 'userA',
    emailVerified: true,
    operation: 'update',
    path: '/users/userA',
    payload: { isBlocked: false, isAdmin: true },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 4,
    name: 'PII scraping on userPrivate',
    actorUid: 'userA',
    emailVerified: true,
    operation: 'get',
    path: '/userPrivate/userB',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 5,
    name: 'Unverified admin email spoof',
    actorUid: 'spoofUid',
    emailVerified: false,
    operation: 'list',
    path: '/reports',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 6,
    name: 'Outsider direct chat message read',
    actorUid: 'userC',
    emailVerified: true,
    operation: 'get',
    path: '/directChats/userA_userB/messages/msg1',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 7,
    name: 'Direct message senderId spoofing',
    actorUid: 'userA',
    emailVerified: true,
    operation: 'create',
    path: '/directChats/userA_userB/messages/msg1',
    payload: { id: 'msg1', senderId: 'userB', text: 'Fake message' },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 8,
    name: 'Non-member group messages access',
    actorUid: 'userC',
    emailVerified: true,
    operation: 'list',
    path: '/groups/grp1/messages',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 9,
    name: 'Group member self-promotion to admin',
    actorUid: 'userC',
    emailVerified: true,
    operation: 'update',
    path: '/groups/grp1/members/userC',
    payload: { role: 'admin' },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 10,
    name: 'Deleting another user message without admin role',
    actorUid: 'userA',
    emailVerified: true,
    operation: 'delete',
    path: '/groups/grp1/messages/msgByUserB',
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 11,
    name: 'ID poisoning with oversized ID',
    actorUid: 'userA',
    emailVerified: true,
    operation: 'create',
    path: `/groups/${'x'.repeat(200)}`,
    payload: { name: 'Oversized' },
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 12,
    name: 'Backdated client timestamp tampering',
    actorUid: 'userA',
    emailVerified: true,
    operation: 'create',
    path: '/groups/grp1/messages/msg99',
    payload: { id: 'msg99', senderId: 'userA', createdAt: '2020-01-01T00:00:00Z' },
    expected: 'PERMISSION_DENIED',
  },
];
