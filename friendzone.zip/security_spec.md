# FRIENDZONE Security Specification (Phase 0 TDD)

## 1. Data Invariants
1. **Identity & PII Isolation**: Public `/users/{userId}` documents contain zero PII (`email`, `fcmToken`). Sensitive user fields reside strictly in `/userPrivate/{userId}`, readable and writable only by the owner or an authorized administrator.
2. **Privilege Escalation Prevention**: Users cannot set `isBlocked: true/false` on their own profile update, nor can they create `/admins/{uid}` documents unless already an administrator or bootstrapped Super Admin (`k065aG6QXceoL5mj6QoLEHrAbR13` / verified `shyamal.tr45@gmail.com`).
3. **Private Chat Master Gate**: Only the two participants listed in `/directChats/{chatId}.participants` (or an admin) can read or write messages in `/directChats/{chatId}/messages/{messageId}`.
4. **Private Group Master Gate**: Only users who have a corresponding membership document at `/groups/{groupId}/members/{uid}` (or an admin) can read group metadata, member lists, or group messages.
5. **Group Admin Permissions**: Only group admins (verified via `get(/groups/{groupId}/members/{uid}).data.role == 'admin'`) or platform admins can add/remove members, promote/demote group admins, or edit group name/description/photo.
6. **Message Ownership**: Users can only send messages with `senderId == request.auth.uid`, and can only delete/soft-delete their own messages (`resource.data.senderId == request.auth.uid`), unless the actor is a group admin or platform admin.
7. **Temporal & Volumetric Integrity**: All `createdAt` / `updatedAt` timestamps must match `request.time`, all document IDs must satisfy `^[a-zA-Z0-9_-]+$` (`<= 128/256`), and every string/list field enforces strict length limits.

## 2. The "Dirty Dozen" Adversarial Payloads
1. **Unauthenticated Write**: Creating `/users/attacker` without `request.auth` -> `PERMISSION_DENIED`.
2. **Profile Impersonation**: User A attempting to create/update `/users/userB` -> `PERMISSION_DENIED`.
3. **Self-Unblock / Shadow Field**: Blocked user updating `/users/userA` with `{ isBlocked: false }` or `{ role: 'admin' }` -> `PERMISSION_DENIED`.
4. **PII Scraping**: User A calling `get` on `/userPrivate/userB` -> `PERMISSION_DENIED`.
5. **Admin Spoof via Unverified Email**: User with unverified email `shyamal.tr45@gmail.com` (`email_verified: false`) reading `/reports` -> `PERMISSION_DENIED`.
6. **Unauthorized Direct Message Read**: User C reading `/directChats/userA_userB/messages/msg1` -> `PERMISSION_DENIED`.
7. **Direct Message Sender Spoofing**: User A creating `/directChats/userA_userB/messages/msg1` with `senderId: 'userB'` -> `PERMISSION_DENIED`.
8. **Unauthorized Group Message Access**: Non-member User C reading or listing `/groups/grp1/messages` -> `PERMISSION_DENIED`.
9. **Group Role Self-Promotion**: Regular group member updating `/groups/grp1/members/userC` with `{ role: 'admin' }` -> `PERMISSION_DENIED`.
10. **Deleting Another User's Message**: Regular member User A deleting User B's message in `/groups/grp1/messages/msg2` -> `PERMISSION_DENIED`.
11. **ID Poisoning**: Creating `/groups/../../evil` or 500-char document ID -> `PERMISSION_DENIED`.
12. **Client Timestamp Tampering**: Creating a message with backdated `createdAt` not equal to `request.time` -> `PERMISSION_DENIED`.
