import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import {
  User,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendEmailVerification,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
} from 'firebase/auth';
import {
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  serverTimestamp,
  setDoc,
  updateDoc,
  writeBatch,
} from 'firebase/firestore';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from '../lib/firebase';
import { generateUniqueCode, normalizePhoneNumber, sanitizeString, sanitizeUrl, SUPER_ADMIN_UID } from '../lib/utils';
import { AppSettings, LIMITS, UserPrivate, UserProfile } from '../types';

interface AuthContextValue {
  firebaseUser: User | null;
  profile: UserProfile | null;
  privateData: UserPrivate | null;
  appSettings: AppSettings;
  isAdmin: boolean;
  isSuperAdmin: boolean;
  loading: boolean;
  authError: string | null;
  clearAuthError: () => void;
  signInWithGoogle: () => Promise<void>;
  loginWithEmail: (email: string, password: string) => Promise<void>;
  registerWithEmail: (name: string, email: string, password: string, bio?: string, phoneNumber?: string) => Promise<void>;
  logout: () => Promise<void>;
  updateMyProfile: (updates: { displayName?: string; bio?: string; photoURL?: string; phoneNumber?: string }) => Promise<void>;
  updatePrivatePrefs: (updates: Partial<Pick<UserPrivate, 'notificationsEnabled' | 'themePreference' | 'fcmToken'>>) => Promise<void>;
}

const DEFAULT_SETTINGS: AppSettings = {
  allowRegistration: true,
  allowGroupCreation: true,
  maxGroupSize: 250,
  maxFileSizeMB: 10,
  maintenanceMode: false,
  announcementBanner: '',
  updatedAt: null,
  updatedBy: SUPER_ADMIN_UID,
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

function mapAuthErrorMessage(err: unknown): string {
  const msg = err instanceof Error ? err.message : String(err);
  if (msg.includes('auth/operation-not-allowed')) {
    return 'Email/Password sign-in is not yet enabled in Firebase Console. Enable Email/Password under Authentication → Sign-in method, or continue with Google Sign-In.';
  }
  if (msg.includes('auth/email-already-in-use')) {
    return 'An account with this email already exists. Please sign in instead.';
  }
  if (msg.includes('auth/invalid-credential') || msg.includes('auth/wrong-password') || msg.includes('auth/user-not-found')) {
    return 'Invalid email or password. Please verify your credentials.';
  }
  if (msg.includes('auth/weak-password')) {
    return 'Password should be at least 6 characters long.';
  }
  if (msg.includes('auth/popup-closed-by-user')) {
    return 'Sign-in popup was closed before completion.';
  }
  if (msg.includes('auth/popup-blocked')) {
    return 'Browser blocked the sign-in popup. Please allow popups for this site.';
  }
  return msg;
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [privateData, setPrivateData] = useState<UserPrivate | null>(null);
  const [appSettings, setAppSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [isAdminDoc, setIsAdminDoc] = useState(false);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);

  const clearAuthError = useCallback(() => setAuthError(null), []);

  // Listen to global app settings
  useEffect(() => {
    const settingsRef = doc(db, 'appSettings', 'global');
    const unsub = onSnapshot(
      settingsRef,
      (snap) => {
        if (snap.exists()) {
          setAppSettings(snap.data() as AppSettings);
        }
      },
      () => {
        // Fallback silently to default settings if not yet created
      }
    );
    return () => unsub();
  }, []);

  const ensureUserProvisioned = useCallback(async (user: User, preferredName?: string, preferredBio?: string, preferredPhone?: string) => {
    const userRef = doc(db, 'users', user.uid);
    const privRef = doc(db, 'userPrivate', user.uid);

    try {
      const snap = await getDoc(userRef);
      if (!snap.exists()) {
        const displayName = sanitizeString(
          preferredName || user.displayName || user.email?.split('@')[0] || 'FRIENDZONE Member',
          LIMITS.NAME_MAX
        );
        const uniqueCode = generateUniqueCode(user.uid);
        const photoURL = sanitizeUrl(user.photoURL || '');
        const bio = sanitizeString(preferredBio || 'Hey there! I am using FRIENDZONE.', LIMITS.BIO_MAX);
        const cleanPhone = sanitizeString(preferredPhone || '', 24);
        const normalizedPhone = normalizePhoneNumber(cleanPhone);

        const batch = writeBatch(db);
        batch.set(userRef, {
          uid: user.uid,
          uniqueCode,
          displayName,
          photoURL,
          bio,
          isOnline: true,
          lastSeen: serverTimestamp(),
          isBlocked: false,
          isDemo: false,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        batch.set(privRef, {
          uid: user.uid,
          email: sanitizeString(user.email || '', 160),
          phoneNumber: cleanPhone,
          fcmToken: '',
          notificationsEnabled: true,
          themePreference: 'system',
          updatedAt: serverTimestamp(),
        });

        batch.set(doc(db, 'userCodeLookup', uniqueCode), {
          uid: user.uid,
          uniqueCode,
          displayName,
          createdAt: serverTimestamp(),
        });

        if (normalizedPhone.length >= 6) {
          batch.set(doc(db, 'userPhoneLookup', normalizedPhone), {
            uid: user.uid,
            normalizedPhone,
            displayName,
            createdAt: serverTimestamp(),
          });
        }

        await batch.commit();
      } else {
        await updateDoc(userRef, {
          isOnline: true,
          lastSeen: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        const privSnap = await getDoc(privRef);
        if (!privSnap.exists()) {
          await setDoc(privRef, {
            uid: user.uid,
            email: sanitizeString(user.email || '', 160),
            phoneNumber: '',
            fcmToken: '',
            notificationsEnabled: true,
            themePreference: 'system',
            updatedAt: serverTimestamp(),
          });
        }
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `users/${user.uid}`);
    }
  }, []);

  useEffect(() => {
    let unsubProfile: (() => void) | null = null;
    let unsubPrivate: (() => void) | null = null;
    let unsubAdmin: (() => void) | null = null;

    const unsubAuth = onAuthStateChanged(auth, async (user) => {
      if (unsubProfile) unsubProfile();
      if (unsubPrivate) unsubPrivate();
      if (unsubAdmin) unsubAdmin();

      setFirebaseUser(user);

      if (!user) {
        setProfile(null);
        setPrivateData(null);
        setIsAdminDoc(false);
        setLoading(false);
        return;
      }

      try {
        await ensureUserProvisioned(user);

        unsubProfile = onSnapshot(
          doc(db, 'users', user.uid),
          (snap) => {
            if (snap.exists()) {
              setProfile(snap.data() as UserProfile);
            }
            setLoading(false);
          },
          (err) => handleFirestoreError(err, OperationType.GET, `users/${user.uid}`)
        );

        unsubPrivate = onSnapshot(
          doc(db, 'userPrivate', user.uid),
          (snap) => {
            if (snap.exists()) {
              setPrivateData(snap.data() as UserPrivate);
            }
          },
          (err) => handleFirestoreError(err, OperationType.GET, `userPrivate/${user.uid}`)
        );

        unsubAdmin = onSnapshot(
          doc(db, 'admins', user.uid),
          (snap) => {
            setIsAdminDoc(snap.exists());
          },
          () => {
            setIsAdminDoc(false);
          }
        );
      } catch {
        setLoading(false);
      }
    });

    return () => {
      unsubAuth();
      if (unsubProfile) unsubProfile();
      if (unsubPrivate) unsubPrivate();
      if (unsubAdmin) unsubAdmin();
    };
  }, [ensureUserProvisioned]);

  // Presence lifecycle: mark offline on tab close / hide
  useEffect(() => {
    if (!firebaseUser) return;
    const uid = firebaseUser.uid;

    const setPresence = async (online: boolean) => {
      try {
        await updateDoc(doc(db, 'users', uid), {
          isOnline: online,
          lastSeen: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } catch {
        // Ignore network errors on unload
      }
    };

    const handleVisibility = () => {
      setPresence(document.visibilityState === 'visible');
    };
    const handleUnload = () => {
      setPresence(false);
    };

    document.addEventListener('visibilitychange', handleVisibility);
    window.addEventListener('pagehide', handleUnload);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibility);
      window.removeEventListener('pagehide', handleUnload);
    };
  }, [firebaseUser]);

  const signInWithGoogle = async () => {
    setAuthError(null);
    try {
      const cred = await signInWithPopup(auth, googleProvider);
      await ensureUserProvisioned(cred.user);
    } catch (err) {
      setAuthError(mapAuthErrorMessage(err));
      throw err;
    }
  };

  const loginWithEmail = async (email: string, password: string) => {
    setAuthError(null);
    try {
      const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
      await ensureUserProvisioned(cred.user);
    } catch (err) {
      setAuthError(mapAuthErrorMessage(err));
      throw err;
    }
  };

  const registerWithEmail = async (name: string, email: string, password: string, bio?: string, phoneNumber?: string) => {
    setAuthError(null);
    if (!appSettings.allowRegistration) {
      const msg = 'New registrations are currently paused by the administrator.';
      setAuthError(msg);
      throw new Error(msg);
    }
    try {
      const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
      const cleanName = sanitizeString(name, LIMITS.NAME_MAX) || 'FRIENDZONE Member';
      await updateProfile(cred.user, { displayName: cleanName });
      await ensureUserProvisioned(cred.user, cleanName, bio, phoneNumber);
      try {
        await sendEmailVerification(cred.user);
      } catch {
        // Verification email best-effort
      }
    } catch (err) {
      setAuthError(mapAuthErrorMessage(err));
      throw err;
    }
  };

  const logout = async () => {
    if (firebaseUser) {
      try {
        await updateDoc(doc(db, 'users', firebaseUser.uid), {
          isOnline: false,
          lastSeen: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } catch {
        // Proceed with sign out even if presence update fails
      }
    }
    await signOut(auth);
  };

  const updateMyProfile = async (updates: { displayName?: string; bio?: string; photoURL?: string; phoneNumber?: string }) => {
    if (!firebaseUser || !profile) return;
    const displayName =
      updates.displayName !== undefined
        ? sanitizeString(updates.displayName, LIMITS.NAME_MAX) || profile.displayName
        : profile.displayName;
    const bio =
      updates.bio !== undefined ? sanitizeString(updates.bio, LIMITS.BIO_MAX) : profile.bio;
    const photoURL =
      updates.photoURL !== undefined ? sanitizeUrl(updates.photoURL) : profile.photoURL;

    try {
      const batch = writeBatch(db);
      batch.update(doc(db, 'users', firebaseUser.uid), {
        displayName,
        bio,
        photoURL,
        updatedAt: serverTimestamp(),
      });
      if (displayName !== profile.displayName) {
        batch.update(doc(db, 'userCodeLookup', profile.uniqueCode), {
          displayName,
        });
      }

      if (updates.phoneNumber !== undefined) {
        const cleanPhone = sanitizeString(updates.phoneNumber, 24);
        const oldNormalized = normalizePhoneNumber(privateData?.phoneNumber || '');
        const newNormalized = normalizePhoneNumber(cleanPhone);

        if (oldNormalized && oldNormalized !== newNormalized) {
          try {
            await deleteDoc(doc(db, 'userPhoneLookup', oldNormalized));
          } catch {
            // Ignore if old lookup did not exist
          }
        }

        batch.update(doc(db, 'userPrivate', firebaseUser.uid), {
          phoneNumber: cleanPhone,
          updatedAt: serverTimestamp(),
        });

        if (newNormalized.length >= 6) {
          batch.set(doc(db, 'userPhoneLookup', newNormalized), {
            uid: firebaseUser.uid,
            normalizedPhone: newNormalized,
            displayName,
            createdAt: serverTimestamp(),
          });
        }
      }

      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${firebaseUser.uid}`);
    }
  };

  const updatePrivatePrefs = async (
    updates: Partial<Pick<UserPrivate, 'notificationsEnabled' | 'themePreference' | 'fcmToken'>>
  ) => {
    if (!firebaseUser) return;
    try {
      await updateDoc(doc(db, 'userPrivate', firebaseUser.uid), {
        ...updates,
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `userPrivate/${firebaseUser.uid}`);
    }
  };

  const isSuperAdmin =
    !!firebaseUser &&
    (firebaseUser.uid === SUPER_ADMIN_UID ||
      (firebaseUser.emailVerified && firebaseUser.email === 'shyamal.tr45@gmail.com'));

  const isAdmin = isSuperAdmin || isAdminDoc;

  return (
    <AuthContext.Provider
      value={{
        firebaseUser,
        profile,
        privateData,
        appSettings,
        isAdmin,
        isSuperAdmin,
        loading,
        authError,
        clearAuthError,
        signInWithGoogle,
        loginWithEmail,
        registerWithEmail,
        logout,
        updateMyProfile,
        updatePrivatePrefs,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
