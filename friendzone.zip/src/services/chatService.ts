import {
  collection,
  collectionGroup,
  deleteDoc,
  doc,
  getCountFromServer,
  getDoc,
  getDocs,
  limit,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import {
  DEMO_ASSETS,
  getDeterministicPairId,
  normalizePhoneNumber,
  sanitizeString,
  sanitizeUrl,
} from '../lib/utils';
import {
  AdminRecord,
  AppSettings,
  ChatMessage,
  DirectChat,
  Friendship,
  Group,
  GroupMember,
  LIMITS,
  NotificationItem,
  ReportItem,
  UserProfile,
} from '../types';

function makeId(prefix = 'id'): string {
  const rand = Math.random().toString(36).slice(2, 10);
  return `${prefix}_${Date.now()}_${rand}`;
}

export async function lookupUserByUniqueCode(rawCode: string): Promise<UserProfile | null> {
  const code = rawCode.trim().toUpperCase().replace(/[^A-Z0-9-]/g, '');
  if (!code || code.length < 4) return null;

  const lookupPath = `userCodeLookup/${code}`;
  try {
    const snap = await getDoc(doc(db, 'userCodeLookup', code));
    if (!snap.exists()) return null;
    const { uid } = snap.data() as { uid: string };
    const userSnap = await getDoc(doc(db, 'users', uid));
    if (!userSnap.exists()) return null;
    return userSnap.data() as UserProfile;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, lookupPath);
  }
}

export async function lookupUserByPhoneNumber(rawPhone: string): Promise<UserProfile | null> {
  const normalized = normalizePhoneNumber(rawPhone);
  if (normalized.length < 6) return null;

  const lookupPath = `userPhoneLookup/${normalized}`;
  try {
    const snap = await getDoc(doc(db, 'userPhoneLookup', normalized));
    if (!snap.exists()) return null;
    const { uid } = snap.data() as { uid: string };
    const userSnap = await getDoc(doc(db, 'users', uid));
    if (!userSnap.exists()) return null;
    return userSnap.data() as UserProfile;
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, lookupPath);
  }
}

export async function addFriendByNameAndNumber(
  currentUser: UserProfile,
  name: string,
  phoneNumber: string
): Promise<{
  outcome: 'request_sent' | 'already_friends' | 'already_pending' | 'saved_contact';
  matchedUser: UserProfile | null;
  nameCandidates: UserProfile[];
}> {
  const cleanName = sanitizeString(name, LIMITS.NAME_MAX);
  const cleanPhone = sanitizeString(phoneNumber, 24);
  const normalizedPhone = normalizePhoneNumber(cleanPhone);

  if (!cleanName) throw new Error('Please enter your friend’s name.');
  if (normalizedPhone.length < 6) {
    throw new Error('Please enter a valid phone number (at least 6 digits).');
  }

  const matchedUser = await lookupUserByPhoneNumber(normalizedPhone);
  if (matchedUser && matchedUser.uid === currentUser.uid) {
    throw new Error('This phone number is linked to your own account.');
  }

  // Save/update personal contact entry in Firestore
  const contactId = `cnt_${normalizedPhone}`;
  try {
    await setDoc(doc(db, 'users', currentUser.uid, 'contacts', contactId), {
      id: contactId,
      name: cleanName,
      phoneNumber: cleanPhone,
      normalizedPhone,
      linkedUid: matchedUser ? matchedUser.uid : '',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `users/${currentUser.uid}/contacts/${contactId}`);
  }

  if (matchedUser) {
    const pairId = getDeterministicPairId(currentUser.uid, matchedUser.uid);
    const fSnap = await getDoc(doc(db, 'friendships', pairId));
    if (fSnap.exists()) {
      const fData = fSnap.data() as Friendship;
      if (fData.status === 'accepted') {
        return { outcome: 'already_friends', matchedUser, nameCandidates: [] };
      }
      if (fData.status === 'pending') {
        return { outcome: 'already_pending', matchedUser, nameCandidates: [] };
      }
    }
    await sendFriendRequest(currentUser, matchedUser);
    return { outcome: 'request_sent', matchedUser, nameCandidates: [] };
  }

  const nameCandidates = await searchActiveUsers(cleanName, currentUser.uid);
  return { outcome: 'saved_contact', matchedUser: null, nameCandidates };
}

export async function deleteSavedContact(myUid: string, contactId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'users', myUid, 'contacts', contactId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `users/${myUid}/contacts/${contactId}`);
  }
}

export async function searchActiveUsers(term: string, excludeUid: string): Promise<UserProfile[]> {
  try {
    const q = query(collection(db, 'users'), where('isBlocked', '==', false), limit(50));
    const snap = await getDocs(q);
    const lower = term.trim().toLowerCase();
    return snap.docs
      .map((d) => d.data() as UserProfile)
      .filter((u) => u.uid !== excludeUid)
      .filter(
        (u) =>
          !lower ||
          u.displayName.toLowerCase().includes(lower) ||
          u.uniqueCode.toLowerCase().includes(lower) ||
          u.bio.toLowerCase().includes(lower)
      );
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'users');
  }
}

export async function sendFriendRequest(sender: UserProfile, recipient: UserProfile): Promise<void> {
  if (sender.uid === recipient.uid) {
    throw new Error('You cannot add yourself as a friend.');
  }
  const pairId = getDeterministicPairId(sender.uid, recipient.uid);
  const fRef = doc(db, 'friendships', pairId);

  try {
    const existing = await getDoc(fRef);
    if (existing.exists()) {
      const data = existing.data() as Friendship;
      if (data.status === 'accepted') throw new Error('You are already friends.');
      if (data.status === 'pending') throw new Error('A friend request is already pending.');
      await deleteDoc(fRef);
    }

    const sortedUsers = [sender.uid, recipient.uid].sort();
    const notifId = makeId('notif');
    const batch = writeBatch(db);
    batch.set(fRef, {
      id: pairId,
      users: sortedUsers,
      requesterId: sender.uid,
      recipientId: recipient.uid,
      status: 'pending',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    batch.set(doc(db, 'notifications', notifId), {
      id: notifId,
      recipientId: recipient.uid,
      senderId: sender.uid,
      senderName: sanitizeString(sender.displayName, LIMITS.NAME_MAX),
      type: 'friend_request',
      title: 'New Friend Request',
      body: sanitizeString(`${sender.displayName} sent you a friend request.`, 300),
      targetType: 'friends',
      targetId: pairId,
      read: false,
      createdAt: serverTimestamp(),
    });
    await batch.commit();
  } catch (err) {
    if (err instanceof Error && (err.message.includes('already') || err.message.includes('yourself'))) {
      throw err;
    }
    handleFirestoreError(err, OperationType.WRITE, `friendships/${pairId}`);
  }
}

export async function respondFriendRequest(
  friendship: Friendship,
  currentUser: UserProfile,
  decision: 'accepted' | 'declined'
): Promise<void> {
  const fRef = doc(db, 'friendships', friendship.id);
  try {
    const batch = writeBatch(db);
    batch.update(fRef, {
      status: decision,
      updatedAt: serverTimestamp(),
    });

    if (decision === 'accepted') {
      const notifId = makeId('notif');
      batch.set(doc(db, 'notifications', notifId), {
        id: notifId,
        recipientId: friendship.requesterId,
        senderId: currentUser.uid,
        senderName: sanitizeString(currentUser.displayName, LIMITS.NAME_MAX),
        type: 'friend_accepted',
        title: 'Friend Request Accepted',
        body: sanitizeString(`${currentUser.displayName} accepted your friend request.`, 300),
        targetType: 'friends',
        targetId: friendship.id,
        read: false,
        createdAt: serverTimestamp(),
      });
    }
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `friendships/${friendship.id}`);
  }
}

export async function removeFriendship(friendshipId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'friendships', friendshipId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `friendships/${friendshipId}`);
  }
}

export async function ensureDirectChat(myUid: string, friendUid: string): Promise<string> {
  const sorted = [myUid, friendUid].sort();
  const chatId = `${sorted[0]}_${sorted[1]}`;
  const chatRef = doc(db, 'directChats', chatId);
  try {
    const snap = await getDoc(chatRef);
    if (!snap.exists()) {
      await setDoc(chatRef, {
        id: chatId,
        participantA: sorted[0],
        participantB: sorted[1],
        participants: sorted,
        unreadA: 0,
        unreadB: 0,
        lastMessage: '',
        lastMessageAt: serverTimestamp(),
        lastSenderId: '',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
    return chatId;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `directChats/${chatId}`);
  }
}

export async function sendDirectMessage(params: {
  chat: DirectChat;
  sender: UserProfile;
  recipientUid: string;
  text: string;
  mediaURL?: string;
  mediaType?: 'none' | 'image' | 'file';
  fileName?: string;
  replyTo?: ChatMessage | null;
}): Promise<void> {
  const { chat, sender, recipientUid, text, mediaURL = '', mediaType = 'none', fileName = '', replyTo } = params;
  const cleanText = sanitizeString(text, LIMITS.MESSAGE_MAX);
  if (!cleanText && !mediaURL) return;

  const msgId = makeId('msg');
  const notifId = makeId('notif');
  const preview = cleanText
    ? sanitizeString(cleanText, 120)
    : mediaType === 'image'
      ? 'Shared an image'
      : `Shared file: ${fileName || 'Attachment'}`;

  const isSenderA = sender.uid === chat.participantA;
  const nextUnreadA = isSenderA ? 0 : chat.unreadA + 1;
  const nextUnreadB = isSenderA ? chat.unreadB + 1 : 0;

  try {
    const batch = writeBatch(db);
    batch.set(doc(db, 'directChats', chat.id, 'messages', msgId), {
      id: msgId,
      senderId: sender.uid,
      senderName: sanitizeString(sender.displayName, LIMITS.NAME_MAX),
      senderPhoto: sanitizeUrl(sender.photoURL),
      text: cleanText,
      mediaURL: sanitizeUrl(mediaURL),
      mediaType,
      fileName: sanitizeString(fileName, 255),
      replyToId: replyTo?.id || '',
      replyToText: sanitizeString(replyTo?.text || (replyTo?.mediaType === 'image' ? 'Image' : replyTo?.fileName || ''), 300),
      replyToSender: sanitizeString(replyTo?.senderName || '', LIMITS.NAME_MAX),
      deleted: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    batch.update(doc(db, 'directChats', chat.id), {
      lastMessage: preview,
      lastMessageAt: serverTimestamp(),
      lastSenderId: sender.uid,
      unreadA: nextUnreadA,
      unreadB: nextUnreadB,
      updatedAt: serverTimestamp(),
    });

    if (!recipientUid.startsWith('demo_')) {
      batch.set(doc(db, 'notifications', notifId), {
        id: notifId,
        recipientId: recipientUid,
        senderId: sender.uid,
        senderName: sanitizeString(sender.displayName, LIMITS.NAME_MAX),
        type: 'direct_message',
        title: sanitizeString(sender.displayName, 120),
        body: sanitizeString(preview, 300),
        targetType: 'chat',
        targetId: chat.id,
        read: false,
        createdAt: serverTimestamp(),
      });
    }

    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `directChats/${chat.id}/messages/${msgId}`);
  }
}

export async function markDirectChatRead(chat: DirectChat, myUid: string): Promise<void> {
  const isA = myUid === chat.participantA;
  if ((isA && chat.unreadA === 0) || (!isA && chat.unreadB === 0)) return;
  try {
    await updateDoc(doc(db, 'directChats', chat.id), {
      ...(isA ? { unreadA: 0 } : { unreadB: 0 }),
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `directChats/${chat.id}`);
  }
}

export async function deleteDirectMessage(chatId: string, messageId: string): Promise<void> {
  try {
    await updateDoc(doc(db, 'directChats', chatId, 'messages', messageId), {
      deleted: true,
      text: 'This message was deleted',
      mediaURL: '',
      mediaType: 'none',
      fileName: '',
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `directChats/${chatId}/messages/${messageId}`);
  }
}

export async function createGroup(params: {
  creator: UserProfile;
  name: string;
  description: string;
  photoURL?: string;
  initialMembers: UserProfile[];
}): Promise<string> {
  const { creator, name, description, photoURL = '', initialMembers } = params;
  const cleanName = sanitizeString(name, LIMITS.GROUP_NAME_MAX);
  if (!cleanName) throw new Error('Group name is required.');

  const groupId = makeId('grp');
  const uniqueMembers = initialMembers.filter((m) => m.uid !== creator.uid);
  const memberCount = 1 + uniqueMembers.length;

  try {
    const batch = writeBatch(db);
    batch.set(doc(db, 'groups', groupId), {
      id: groupId,
      name: cleanName,
      description: sanitizeString(description, LIMITS.GROUP_DESC_MAX),
      photoURL: sanitizeUrl(photoURL),
      createdBy: creator.uid,
      memberCount,
      lastMessage: `${creator.displayName} created "${cleanName}"`,
      lastMessageAt: serverTimestamp(),
      lastSenderName: sanitizeString(creator.displayName, LIMITS.NAME_MAX),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    batch.set(doc(db, 'groups', groupId, 'members', creator.uid), {
      uid: creator.uid,
      displayName: sanitizeString(creator.displayName, LIMITS.NAME_MAX),
      photoURL: sanitizeUrl(creator.photoURL),
      role: 'admin',
      joinedAt: serverTimestamp(),
    });

    batch.set(doc(db, 'users', creator.uid, 'groups', groupId), {
      groupId,
      name: cleanName,
      photoURL: sanitizeUrl(photoURL),
      role: 'admin',
      lastReadAt: serverTimestamp(),
      joinedAt: serverTimestamp(),
    });

    for (const member of uniqueMembers) {
      batch.set(doc(db, 'groups', groupId, 'members', member.uid), {
        uid: member.uid,
        displayName: sanitizeString(member.displayName, LIMITS.NAME_MAX),
        photoURL: sanitizeUrl(member.photoURL),
        role: 'member',
        joinedAt: serverTimestamp(),
      });
      batch.set(doc(db, 'users', member.uid, 'groups', groupId), {
        groupId,
        name: cleanName,
        photoURL: sanitizeUrl(photoURL),
        role: 'member',
        lastReadAt: serverTimestamp(),
        joinedAt: serverTimestamp(),
      });
      if (!member.uid.startsWith('demo_')) {
        const notifId = makeId('notif');
        batch.set(doc(db, 'notifications', notifId), {
          id: notifId,
          recipientId: member.uid,
          senderId: creator.uid,
          senderName: sanitizeString(creator.displayName, LIMITS.NAME_MAX),
          type: 'group_invite',
          title: 'Added to Group',
          body: sanitizeString(`${creator.displayName} added you to ${cleanName}.`, 300),
          targetType: 'group',
          targetId: groupId,
          read: false,
          createdAt: serverTimestamp(),
        });
      }
    }

    await batch.commit();
    return groupId;
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `groups/${groupId}`);
  }
}

export async function addMemberToGroup(
  group: Group,
  actor: UserProfile,
  targetUser: UserProfile
): Promise<void> {
  const memberRef = doc(db, 'groups', group.id, 'members', targetUser.uid);
  try {
    const existing = await getDoc(memberRef);
    if (existing.exists()) {
      throw new Error(`${targetUser.displayName} is already a member of this group.`);
    }

    const batch = writeBatch(db);
    batch.set(memberRef, {
      uid: targetUser.uid,
      displayName: sanitizeString(targetUser.displayName, LIMITS.NAME_MAX),
      photoURL: sanitizeUrl(targetUser.photoURL),
      role: 'member',
      joinedAt: serverTimestamp(),
    });
    batch.set(doc(db, 'users', targetUser.uid, 'groups', group.id), {
      groupId: group.id,
      name: group.name,
      photoURL: group.photoURL,
      role: 'member',
      lastReadAt: serverTimestamp(),
      joinedAt: serverTimestamp(),
    });
    batch.update(doc(db, 'groups', group.id), {
      memberCount: group.memberCount + 1,
      updatedAt: serverTimestamp(),
    });

    if (!targetUser.uid.startsWith('demo_')) {
      const notifId = makeId('notif');
      batch.set(doc(db, 'notifications', notifId), {
        id: notifId,
        recipientId: targetUser.uid,
        senderId: actor.uid,
        senderName: sanitizeString(actor.displayName, LIMITS.NAME_MAX),
        type: 'group_invite',
        title: 'Group Invitation',
        body: sanitizeString(`${actor.displayName} added you to ${group.name}.`, 300),
        targetType: 'group',
        targetId: group.id,
        read: false,
        createdAt: serverTimestamp(),
      });
    }

    await batch.commit();
  } catch (err) {
    if (err instanceof Error && err.message.includes('already a member')) throw err;
    handleFirestoreError(err, OperationType.WRITE, `groups/${group.id}/members/${targetUser.uid}`);
  }
}

export async function updateGroupDetails(
  groupId: string,
  updates: { name: string; description: string; photoURL: string }
): Promise<void> {
  try {
    await updateDoc(doc(db, 'groups', groupId), {
      name: sanitizeString(updates.name, LIMITS.GROUP_NAME_MAX),
      description: sanitizeString(updates.description, LIMITS.GROUP_DESC_MAX),
      photoURL: sanitizeUrl(updates.photoURL),
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `groups/${groupId}`);
  }
}

export async function setGroupMemberRole(
  groupId: string,
  memberUid: string,
  role: 'admin' | 'member'
): Promise<void> {
  try {
    const batch = writeBatch(db);
    batch.update(doc(db, 'groups', groupId, 'members', memberUid), { role });
    batch.update(doc(db, 'users', memberUid, 'groups', groupId), { role });
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `groups/${groupId}/members/${memberUid}`);
  }
}

export async function removeGroupMember(
  group: Group,
  memberUid: string
): Promise<void> {
  try {
    const batch = writeBatch(db);
    batch.delete(doc(db, 'groups', group.id, 'members', memberUid));
    batch.delete(doc(db, 'users', memberUid, 'groups', group.id));
    batch.update(doc(db, 'groups', group.id), {
      memberCount: Math.max(1, group.memberCount - 1),
      updatedAt: serverTimestamp(),
    });
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `groups/${group.id}/members/${memberUid}`);
  }
}

export async function sendGroupMessage(params: {
  group: Group;
  sender: UserProfile;
  members: GroupMember[];
  text: string;
  mediaURL?: string;
  mediaType?: 'none' | 'image' | 'file';
  fileName?: string;
  replyTo?: ChatMessage | null;
}): Promise<void> {
  const { group, sender, members, text, mediaURL = '', mediaType = 'none', fileName = '', replyTo } = params;
  const cleanText = sanitizeString(text, LIMITS.MESSAGE_MAX);
  if (!cleanText && !mediaURL) return;

  const msgId = makeId('gmsg');
  const preview = cleanText
    ? sanitizeString(cleanText, 120)
    : mediaType === 'image'
      ? 'Shared an image'
      : `Shared file: ${fileName || 'Attachment'}`;

  try {
    const batch = writeBatch(db);
    batch.set(doc(db, 'groups', group.id, 'messages', msgId), {
      id: msgId,
      senderId: sender.uid,
      senderName: sanitizeString(sender.displayName, LIMITS.NAME_MAX),
      senderPhoto: sanitizeUrl(sender.photoURL),
      text: cleanText,
      mediaURL: sanitizeUrl(mediaURL),
      mediaType,
      fileName: sanitizeString(fileName, 255),
      replyToId: replyTo?.id || '',
      replyToText: sanitizeString(replyTo?.text || (replyTo?.mediaType === 'image' ? 'Image' : replyTo?.fileName || ''), 300),
      replyToSender: sanitizeString(replyTo?.senderName || '', LIMITS.NAME_MAX),
      deleted: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    batch.update(doc(db, 'groups', group.id), {
      lastMessage: `${sender.displayName}: ${preview}`.slice(0, 500),
      lastMessageAt: serverTimestamp(),
      lastSenderName: sanitizeString(sender.displayName, LIMITS.NAME_MAX),
      updatedAt: serverTimestamp(),
    });

    // Notify up to 15 non-demo members in real time
    const recipients = members
      .filter((m) => m.uid !== sender.uid && !m.uid.startsWith('demo_'))
      .slice(0, 15);
    for (const member of recipients) {
      const notifId = makeId('notif');
      batch.set(doc(db, 'notifications', notifId), {
        id: notifId,
        recipientId: member.uid,
        senderId: sender.uid,
        senderName: sanitizeString(sender.displayName, LIMITS.NAME_MAX),
        type: 'group_message',
        title: sanitizeString(group.name, 120),
        body: sanitizeString(`${sender.displayName}: ${preview}`, 300),
        targetType: 'group',
        targetId: group.id,
        read: false,
        createdAt: serverTimestamp(),
      });
    }

    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `groups/${group.id}/messages/${msgId}`);
  }
}

export async function markGroupRead(myUid: string, groupId: string): Promise<void> {
  try {
    await updateDoc(doc(db, 'users', myUid, 'groups', groupId), {
      lastReadAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `users/${myUid}/groups/${groupId}`);
  }
}

export async function deleteGroupMessage(groupId: string, messageId: string): Promise<void> {
  try {
    await updateDoc(doc(db, 'groups', groupId, 'messages', messageId), {
      deleted: true,
      text: 'This message was deleted',
      mediaURL: '',
      mediaType: 'none',
      fileName: '',
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `groups/${groupId}/messages/${messageId}`);
  }
}

export async function deleteEntireGroup(groupId: string): Promise<void> {
  try {
    const membersSnap = await getDocs(collection(db, 'groups', groupId, 'members'));
    const msgsSnap = await getDocs(collection(db, 'groups', groupId, 'messages'));

    const batch = writeBatch(db);
    msgsSnap.docs.forEach((d) => batch.delete(d.ref));
    membersSnap.docs.forEach((d) => {
      batch.delete(d.ref);
      batch.delete(doc(db, 'users', d.id, 'groups', groupId));
    });
    batch.delete(doc(db, 'groups', groupId));
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `groups/${groupId}`);
  }
}

export async function markNotificationRead(notificationId: string): Promise<void> {
  try {
    await updateDoc(doc(db, 'notifications', notificationId), { read: true });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `notifications/${notificationId}`);
  }
}

export async function markAllNotificationsRead(items: NotificationItem[]): Promise<void> {
  const unread = items.filter((n) => !n.read);
  if (unread.length === 0) return;
  try {
    const batch = writeBatch(db);
    unread.forEach((n) => batch.update(doc(db, 'notifications', n.id), { read: true }));
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, 'notifications');
  }
}

export async function deleteNotification(notificationId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'notifications', notificationId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `notifications/${notificationId}`);
  }
}

export async function submitReport(params: {
  reporter: UserProfile;
  targetType: 'user' | 'group' | 'message';
  targetId: string;
  targetLabel: string;
  reason: string;
}): Promise<void> {
  const reportId = makeId('rep');
  try {
    await setDoc(doc(db, 'reports', reportId), {
      id: reportId,
      reporterId: params.reporter.uid,
      reporterName: sanitizeString(params.reporter.displayName, LIMITS.NAME_MAX),
      targetType: params.targetType,
      targetId: sanitizeString(params.targetId, 256),
      targetLabel: sanitizeString(params.targetLabel, 120),
      reason: sanitizeString(params.reason, LIMITS.REPORT_REASON_MAX),
      status: 'open',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `reports/${reportId}`);
  }
}

// ------------------------------------------------------------------
// Sample Demo Workspace Seeder (Writes real Firestore documents)
// ------------------------------------------------------------------
export async function seedDemoWorkspace(currentUser: UserProfile): Promise<void> {
  const mayaUid = 'demo_maya_lin';
  const marcusUid = 'demo_marcus_vance';
  const mayaCode = 'FZ-MAYA2026';
  const marcusCode = 'FZ-MARC2026';

  try {
    const mayaSnap = await getDoc(doc(db, 'users', mayaUid));
    const marcusSnap = await getDoc(doc(db, 'users', marcusUid));

    const batch = writeBatch(db);

    if (!mayaSnap.exists()) {
      batch.set(doc(db, 'users', mayaUid), {
        uid: mayaUid,
        uniqueCode: mayaCode,
        displayName: 'Maya Lin',
        photoURL: DEMO_ASSETS.avatarMaya,
        bio: 'Product designer & weekend photographer. Always down for coffee chats.',
        isOnline: true,
        lastSeen: serverTimestamp(),
        isBlocked: false,
        isDemo: true,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      batch.set(doc(db, 'userCodeLookup', mayaCode), {
        uid: mayaUid,
        uniqueCode: mayaCode,
        displayName: 'Maya Lin',
        createdAt: serverTimestamp(),
      });
      batch.set(doc(db, 'userPhoneLookup', '14155550142'), {
        uid: mayaUid,
        normalizedPhone: '14155550142',
        displayName: 'Maya Lin',
        createdAt: serverTimestamp(),
      });
    }

    if (!marcusSnap.exists()) {
      batch.set(doc(db, 'users', marcusUid), {
        uid: marcusUid,
        uniqueCode: marcusCode,
        displayName: 'Marcus Vance',
        photoURL: DEMO_ASSETS.avatarMarcus,
        bio: 'Full-stack builder & synth enthusiast. Let us build something cool.',
        isOnline: true,
        lastSeen: serverTimestamp(),
        isBlocked: false,
        isDemo: true,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      batch.set(doc(db, 'userCodeLookup', marcusCode), {
        uid: marcusUid,
        uniqueCode: marcusCode,
        displayName: 'Marcus Vance',
        createdAt: serverTimestamp(),
      });
      batch.set(doc(db, 'userPhoneLookup', '14155550198'), {
        uid: marcusUid,
        normalizedPhone: '14155550198',
        displayName: 'Marcus Vance',
        createdAt: serverTimestamp(),
      });
    }

    // Accepted friendships for current user
    const fMayaId = getDeterministicPairId(currentUser.uid, mayaUid);
    const fMarcusId = getDeterministicPairId(currentUser.uid, marcusUid);

    batch.set(doc(db, 'friendships', fMayaId), {
      id: fMayaId,
      users: [currentUser.uid, mayaUid].sort(),
      requesterId: currentUser.uid,
      recipientId: mayaUid,
      status: 'accepted',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    batch.set(doc(db, 'friendships', fMarcusId), {
      id: fMarcusId,
      users: [currentUser.uid, marcusUid].sort(),
      requesterId: currentUser.uid,
      recipientId: marcusUid,
      status: 'accepted',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    // Direct chat with Maya Lin
    const chatParticipants = [currentUser.uid, mayaUid].sort();
    const chatId = `${chatParticipants[0]}_${chatParticipants[1]}`;
    const isMeA = currentUser.uid === chatParticipants[0];

    batch.set(doc(db, 'directChats', chatId), {
      id: chatId,
      participantA: chatParticipants[0],
      participantB: chatParticipants[1],
      participants: chatParticipants,
      unreadA: isMeA ? 1 : 0,
      unreadB: isMeA ? 0 : 1,
      lastMessage: 'Welcome to FRIENDZONE! Try replying to this message or sharing a photo.',
      lastMessageAt: serverTimestamp(),
      lastSenderId: mayaUid,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    const dmMsgId = makeId('dm');
    batch.set(doc(db, 'directChats', chatId, 'messages', dmMsgId), {
      id: dmMsgId,
      senderId: mayaUid,
      senderName: 'Maya Lin',
      senderPhoto: DEMO_ASSETS.avatarMaya,
      text: 'Welcome to FRIENDZONE! Try replying to this message or sharing a photo.',
      mediaURL: '',
      mediaType: 'none',
      fileName: '',
      replyToId: '',
      replyToText: '',
      replyToSender: '',
      deleted: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    // Sample Group: Weekend Creators
    const groupId = `demo_group_${currentUser.uid.replace(/[^a-zA-Z0-9]/g, '').slice(0, 14)}`;
    batch.set(doc(db, 'groups', groupId), {
      id: groupId,
      name: 'Weekend Creators',
      description: 'Share design snippets, weekend side projects, and creative inspiration.',
      photoURL: DEMO_ASSETS.groupWeekendCreators,
      createdBy: currentUser.uid,
      memberCount: 3,
      lastMessage: 'Marcus Vance: Excited for Saturday coffee & build session!',
      lastMessageAt: serverTimestamp(),
      lastSenderName: 'Marcus Vance',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    batch.set(doc(db, 'groups', groupId, 'members', currentUser.uid), {
      uid: currentUser.uid,
      displayName: sanitizeString(currentUser.displayName, LIMITS.NAME_MAX),
      photoURL: sanitizeUrl(currentUser.photoURL),
      role: 'admin',
      joinedAt: serverTimestamp(),
    });
    batch.set(doc(db, 'users', currentUser.uid, 'groups', groupId), {
      groupId,
      name: 'Weekend Creators',
      photoURL: DEMO_ASSETS.groupWeekendCreators,
      role: 'admin',
      lastReadAt: serverTimestamp(),
      joinedAt: serverTimestamp(),
    });

    batch.set(doc(db, 'groups', groupId, 'members', mayaUid), {
      uid: mayaUid,
      displayName: 'Maya Lin',
      photoURL: DEMO_ASSETS.avatarMaya,
      role: 'member',
      joinedAt: serverTimestamp(),
    });
    batch.set(doc(db, 'groups', groupId, 'members', marcusUid), {
      uid: marcusUid,
      displayName: 'Marcus Vance',
      photoURL: DEMO_ASSETS.avatarMarcus,
      role: 'member',
      joinedAt: serverTimestamp(),
    });

    const gMsg1 = makeId('gm1');
    const gMsg2 = makeId('gm2');
    batch.set(doc(db, 'groups', groupId, 'messages', gMsg1), {
      id: gMsg1,
      senderId: mayaUid,
      senderName: 'Maya Lin',
      senderPhoto: DEMO_ASSETS.avatarMaya,
      text: 'Hey everyone! Dropped our new workspace visual moodboard here.',
      mediaURL: DEMO_ASSETS.heroConnect,
      mediaType: 'image',
      fileName: 'workspace_moodboard.jpg',
      replyToId: '',
      replyToText: '',
      replyToSender: '',
      deleted: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    batch.set(doc(db, 'groups', groupId, 'messages', gMsg2), {
      id: gMsg2,
      senderId: marcusUid,
      senderName: 'Marcus Vance',
      senderPhoto: DEMO_ASSETS.avatarMarcus,
      text: 'Excited for Saturday coffee & build session!',
      mediaURL: '',
      mediaType: 'none',
      fileName: '',
      replyToId: gMsg1,
      replyToText: 'Hey everyone! Dropped our new workspace visual moodboard here.',
      replyToSender: 'Maya Lin',
      deleted: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });

    const notifId = makeId('notif');
    batch.set(doc(db, 'notifications', notifId), {
      id: notifId,
      recipientId: currentUser.uid,
      senderId: mayaUid,
      senderName: 'Maya Lin',
      type: 'system',
      title: 'Sample Workspace Ready',
      body: 'Maya Lin & Marcus Vance joined your contacts and Weekend Creators is live.',
      targetType: 'group',
      targetId: groupId,
      read: false,
      createdAt: serverTimestamp(),
    });

    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, 'demo_seed');
  }
}

// ------------------------------------------------------------------
// Admin Operations (Enforced by Firestore Rules isAdmin())
// ------------------------------------------------------------------
export async function fetchAdminStats(): Promise<{
  totalUsers: number;
  totalGroups: number;
  totalMessages: number;
  openReports: number;
}> {
  try {
    const [usersCount, groupsCount, msgsCount, openReportsCount] = await Promise.all([
      getCountFromServer(collection(db, 'users')),
      getCountFromServer(collection(db, 'groups')),
      getCountFromServer(collectionGroup(db, 'messages')),
      getCountFromServer(query(collection(db, 'reports'), where('status', '==', 'open'))),
    ]);
    return {
      totalUsers: usersCount.data().count,
      totalGroups: groupsCount.data().count,
      totalMessages: msgsCount.data().count,
      openReports: openReportsCount.data().count,
    };
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'admin_stats');
  }
}

export async function fetchAllUsersAdmin(): Promise<UserProfile[]> {
  try {
    const snap = await getDocs(query(collection(db, 'users'), orderBy('createdAt', 'desc'), limit(200)));
    return snap.docs.map((d) => d.data() as UserProfile);
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'users');
  }
}

export async function fetchAllGroupsAdmin(): Promise<Group[]> {
  try {
    const snap = await getDocs(query(collection(db, 'groups'), orderBy('createdAt', 'desc'), limit(200)));
    return snap.docs.map((d) => d.data() as Group);
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'groups');
  }
}

export async function fetchAllReportsAdmin(): Promise<ReportItem[]> {
  try {
    const snap = await getDocs(query(collection(db, 'reports'), orderBy('createdAt', 'desc'), limit(200)));
    return snap.docs.map((d) => d.data() as ReportItem);
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'reports');
  }
}

export async function fetchAllAdmins(): Promise<AdminRecord[]> {
  try {
    const snap = await getDocs(collection(db, 'admins'));
    return snap.docs.map((d) => d.data() as AdminRecord);
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, 'admins');
  }
}

export async function toggleUserBlockedAdmin(uid: string, blocked: boolean): Promise<void> {
  try {
    await updateDoc(doc(db, 'users', uid), {
      isBlocked: blocked,
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `users/${uid}`);
  }
}

export async function updateReportStatusAdmin(
  reportId: string,
  status: 'open' | 'resolved' | 'dismissed'
): Promise<void> {
  try {
    await updateDoc(doc(db, 'reports', reportId), {
      status,
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `reports/${reportId}`);
  }
}

export async function removeReportedContentAdmin(report: ReportItem): Promise<void> {
  try {
    if (report.targetType === 'group') {
      await deleteEntireGroup(report.targetId);
    } else if (report.targetType === 'user') {
      await toggleUserBlockedAdmin(report.targetId, true);
    } else if (report.targetType === 'message') {
      // targetId format: "directChats/<chatId>/messages/<msgId>" or "groups/<groupId>/messages/<msgId>"
      const parts = report.targetId.split('/');
      if (parts.length === 4 && (parts[0] === 'directChats' || parts[0] === 'groups')) {
        await updateDoc(doc(db, parts[0], parts[1], parts[2], parts[3]), {
          deleted: true,
          text: 'Removed by moderator',
          mediaURL: '',
          mediaType: 'none',
          fileName: '',
          updatedAt: serverTimestamp(),
        });
      }
    }
    await updateReportStatusAdmin(report.id, 'resolved');
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `reports/${report.id}`);
  }
}

export async function saveAppSettingsAdmin(
  actorUid: string,
  settings: Omit<AppSettings, 'updatedAt' | 'updatedBy'>
): Promise<void> {
  try {
    await setDoc(doc(db, 'appSettings', 'global'), {
      allowRegistration: settings.allowRegistration,
      allowGroupCreation: settings.allowGroupCreation,
      maxGroupSize: Math.max(2, Math.min(5000, Number(settings.maxGroupSize) || 250)),
      maxFileSizeMB: Math.max(1, Math.min(50, Number(settings.maxFileSizeMB) || 10)),
      maintenanceMode: settings.maintenanceMode,
      announcementBanner: sanitizeString(settings.announcementBanner, LIMITS.BANNER_MAX),
      updatedAt: serverTimestamp(),
      updatedBy: actorUid,
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, 'appSettings/global');
  }
}

export async function addPlatformAdminRecord(
  actorUid: string,
  targetUid: string,
  email: string
): Promise<void> {
  try {
    await setDoc(doc(db, 'admins', targetUid), {
      uid: targetUid,
      email: sanitizeString(email, 160),
      role: 'admin',
      addedBy: actorUid,
      createdAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `admins/${targetUid}`);
  }
}

export async function removePlatformAdminRecord(targetUid: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'admins', targetUid));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `admins/${targetUid}`);
  }
}
