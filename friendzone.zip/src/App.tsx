import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft,
  Bell,
  Home,
  LogOut,
  Menu,
  MessageCircle,
  MessageSquareHeart,
  Moon,
  Settings,
  ShieldAlert,
  ShieldCheck,
  Sun,
  User,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import {
  collection,
  doc,
  onSnapshot,
  query,
  where,
} from 'firebase/firestore';
import { AnimatePresence, motion } from 'motion/react';
import { AuthPage } from './components/AuthPage';
import { Avatar } from './components/Avatar';
import { ErrorBoundary } from './components/ErrorBoundary';
import { OfflineIndicator } from './components/OfflineIndicator';
import { PWAInstallButton } from './components/PWAInstallButton';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ThemeProvider, useTheme } from './contexts/ThemeContext';
import { db, handleFirestoreError, OperationType, subscribeForegroundPush } from './lib/firebase';
import { AddFriendsPage } from './pages/AddFriendsPage';
import { AdminPanelPage } from './pages/AdminPanelPage';
import { GroupsPage } from './pages/GroupsPage';
import { HomePage } from './pages/HomePage';
import { MyChatsPage } from './pages/MyChatsPage';
import { NotificationsPage } from './pages/NotificationsPage';
import { ProfilePage } from './pages/ProfilePage';
import { SettingsPage } from './pages/SettingsPage';
import {
  DirectChat,
  Friendship,
  NotificationItem,
  PageRoute,
  SavedContact,
  UserGroupSummary,
  UserProfile,
} from './types';

const WorkspaceShell: React.FC = () => {
  const { firebaseUser, profile, privateData, appSettings, isAdmin, loading, logout, updatePrivatePrefs } = useAuth();
  const { theme, setTheme } = useTheme();

  const [page, setPage] = useState<PageRoute>('home');
  const [pageHistory, setPageHistory] = useState<PageRoute[]>([]);
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);
  const [selectedGroupId, setSelectedGroupId] = useState<string | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [toastAlert, setToastAlert] = useState<{ title: string; body: string } | null>(null);

  const [friendships, setFriendships] = useState<Friendship[]>([]);
  const [directChats, setDirectChats] = useState<DirectChat[]>([]);
  const [userGroups, setUserGroups] = useState<UserGroupSummary[]>([]);
  const [savedContacts, setSavedContacts] = useState<SavedContact[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [usersById, setUsersById] = useState<Record<string, UserProfile>>({});

  const knownNotifIdsRef = useRef<Set<string>>(new Set());
  const initialNotifLoadRef = useRef(true);

  // Sync saved theme preference when loaded from Firestore
  useEffect(() => {
    if (privateData?.themePreference === 'light' || privateData?.themePreference === 'dark') {
      setTheme(privateData.themePreference);
    }
  }, [privateData?.themePreference, setTheme]);

  const handleSelectTheme = (mode: 'light' | 'dark') => {
    setTheme(mode);
    if (firebaseUser) {
      updatePrivatePrefs({ themePreference: mode }).catch(() => {});
    }
  };

  const handleToggleTheme = () => {
    handleSelectTheme(theme === 'dark' ? 'light' : 'dark');
  };

  // Foreground FCM message subscription
  useEffect(() => {
    let unsub = () => {};
    subscribeForegroundPush((title, body) => {
      setToastAlert({ title, body });
      setTimeout(() => setToastAlert(null), 4500);
    }).then((fn) => {
      unsub = fn;
    });
    return () => unsub();
  }, []);

  // Core Firestore real-time subscriptions
  useEffect(() => {
    if (!firebaseUser || !profile) {
      setFriendships([]);
      setDirectChats([]);
      setUserGroups([]);
      setSavedContacts([]);
      setNotifications([]);
      setUsersById({});
      initialNotifLoadRef.current = true;
      knownNotifIdsRef.current.clear();
      return;
    }

    const uid = firebaseUser.uid;

    const unsubFriends = onSnapshot(
      query(collection(db, 'friendships'), where('users', 'array-contains', uid)),
      (snap) => {
        setFriendships(snap.docs.map((d) => d.data() as Friendship));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'friendships')
    );

    const unsubChats = onSnapshot(
      query(collection(db, 'directChats'), where('participants', 'array-contains', uid)),
      (snap) => {
        setDirectChats(snap.docs.map((d) => d.data() as DirectChat));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'directChats')
    );

    const unsubGroups = onSnapshot(
      collection(db, 'users', uid, 'groups'),
      (snap) => {
        setUserGroups(snap.docs.map((d) => d.data() as UserGroupSummary));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, `users/${uid}/groups`)
    );

    const unsubContacts = onSnapshot(
      collection(db, 'users', uid, 'contacts'),
      (snap) => {
        setSavedContacts(snap.docs.map((d) => d.data() as SavedContact));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, `users/${uid}/contacts`)
    );

    const unsubNotifs = onSnapshot(
      query(collection(db, 'notifications'), where('recipientId', '==', uid)),
      (snap) => {
        const items = snap.docs
          .map((d) => d.data() as NotificationItem)
          .sort((a, b) => (b.createdAt?.toMillis() || 0) - (a.createdAt?.toMillis() || 0));

        if (!initialNotifLoadRef.current) {
          for (const item of items) {
            if (!knownNotifIdsRef.current.has(item.id) && !item.read) {
              setToastAlert({ title: item.title, body: item.body });
              setTimeout(() => setToastAlert(null), 4000);
              if (
                privateData?.notificationsEnabled &&
                typeof Notification !== 'undefined' &&
                Notification.permission === 'granted'
              ) {
                try {
                  new Notification(item.title, {
                    body: item.body,
                    icon: '/pwa-192x192.png',
                  });
                } catch {
                  // Ignore Notification constructor failures in constrained contexts
                }
              }
            }
          }
        }
        initialNotifLoadRef.current = false;
        knownNotifIdsRef.current = new Set(items.map((i) => i.id));
        setNotifications(items);
      },
      (err) => handleFirestoreError(err, OperationType.LIST, 'notifications')
    );

    return () => {
      unsubFriends();
      unsubChats();
      unsubGroups();
      unsubContacts();
      unsubNotifs();
    };
  }, [firebaseUser?.uid, !!profile, privateData?.notificationsEnabled]);

  // Subscribe to real-time user profile & online presence for all related peers
  const peerUidsKey = useMemo(() => {
    if (!profile) return '';
    const set = new Set<string>();
    friendships.forEach((f) => f.users.forEach((u) => u !== profile.uid && set.add(u)));
    directChats.forEach((c) => c.participants.forEach((u) => u !== profile.uid && set.add(u)));
    return Array.from(set).sort().join(',');
  }, [friendships, directChats, profile?.uid]);

  useEffect(() => {
    if (!peerUidsKey) return;
    const uids = peerUidsKey.split(',').filter(Boolean);
    const unsubs = uids.map((peerUid) =>
      onSnapshot(
        doc(db, 'users', peerUid),
        (snap) => {
          if (snap.exists()) {
            setUsersById((prev) => ({ ...prev, [peerUid]: snap.data() as UserProfile }));
          }
        },
        () => {}
      )
    );
    return () => unsubs.forEach((u) => u());
  }, [peerUidsKey]);

  const friends = useMemo(() => {
    if (!profile) return [];
    return friendships
      .filter((f) => f.status === 'accepted')
      .map((f) => {
        const peerUid = f.users.find((u) => u !== profile.uid);
        return peerUid ? usersById[peerUid] : undefined;
      })
      .filter((u): u is UserProfile => !!u);
  }, [friendships, usersById, profile?.uid]);

  const unreadChatsCount = useMemo(() => {
    if (!profile) return 0;
    return directChats.reduce((acc, chat) => {
      const isA = chat.participantA === profile.uid;
      return acc + (isA ? chat.unreadA : chat.unreadB);
    }, 0);
  }, [directChats, profile?.uid]);

  const unreadNotifsCount = useMemo(
    () => notifications.filter((n) => !n.read).length,
    [notifications]
  );

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950">
        <div className="flex flex-col items-center gap-3">
          <div className="w-12 h-12 rounded-2xl fz-gradient flex items-center justify-center text-white animate-pulse">
            <MessageSquareHeart className="w-6 h-6" />
          </div>
          <p className="text-sm font-medium text-slate-500 dark:text-slate-400">
            Connecting to FRIENDZONE...
          </p>
        </div>
      </div>
    );
  }

  if (!firebaseUser || !profile) {
    return <AuthPage />;
  }

  if (profile.isBlocked && !isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950 p-6">
        <div className="max-w-md w-full rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-8 text-center">
          <ShieldAlert className="w-10 h-10 text-rose-600 mx-auto" />
          <h1 className="mt-4 font-display text-xl font-bold text-slate-900 dark:text-white">
            Account Suspended
          </h1>
          <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
            Your account has been restricted by a FRIENDZONE administrator. Contact support if you believe this is an error.
          </p>
          <button
            type="button"
            onClick={logout}
            className="mt-6 w-full rounded-xl fz-gradient py-2.5 text-sm font-semibold text-white"
          >
            Sign Out
          </button>
        </div>
      </div>
    );
  }

  if (appSettings.maintenanceMode && !isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950 p-6">
        <div className="max-w-md w-full rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-8 text-center">
          <MessageSquareHeart className="w-10 h-10 text-indigo-600 mx-auto" />
          <h1 className="mt-4 font-display text-xl font-bold text-slate-900 dark:text-white">
            Scheduled Maintenance
          </h1>
          <p className="mt-2 text-sm text-slate-500 dark:text-slate-400">
            FRIENDZONE is temporarily undergoing maintenance. Please check back shortly.
          </p>
          <button
            type="button"
            onClick={logout}
            className="mt-6 w-full rounded-xl border border-slate-200 dark:border-slate-700 py-2.5 text-sm font-medium text-slate-700 dark:text-slate-200"
          >
            Sign Out
          </button>
        </div>
      </div>
    );
  }

  const navItems: {
    id: PageRoute;
    label: string;
    icon: React.FC<{ className?: string }>;
    badge?: number;
  }[] = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'chats', label: 'My Chats', icon: MessageCircle, badge: unreadChatsCount },
    { id: 'groups', label: 'Groups', icon: Users },
    { id: 'friends', label: 'Add Friends', icon: UserPlus },
    { id: 'notifications', label: 'Notifications', icon: Bell, badge: unreadNotifsCount },
    { id: 'profile', label: 'My Profile', icon: User },
    { id: 'settings', label: 'Settings', icon: Settings },
    ...(isAdmin ? [{ id: 'admin' as PageRoute, label: 'Admin Panel', icon: ShieldCheck }] : []),
  ];

  const navigateTo = (next: PageRoute) => {
    if (next !== page) {
      setPageHistory((prev) => [...prev.slice(-19), page]);
      setPage(next);
    }
    setMobileMenuOpen(false);
  };

  const handleOpenChat = (chatId: string) => {
    setSelectedChatId(chatId);
    navigateTo('chats');
  };

  const handleOpenGroup = (groupId: string) => {
    setSelectedGroupId(groupId);
    navigateTo('groups');
  };

  const handleBack = () => {
    if (page === 'chats' && selectedChatId) {
      setSelectedChatId(null);
      return;
    }
    if (page === 'groups' && selectedGroupId) {
      setSelectedGroupId(null);
      return;
    }
    if (pageHistory.length > 0) {
      const prevPage = pageHistory[pageHistory.length - 1];
      setPageHistory((prev) => prev.slice(0, -1));
      setPage(prevPage);
      return;
    }
    if (page !== 'home') {
      setPage('home');
    }
  };

  const canGoBack = page !== 'home' || pageHistory.length > 0;

  return (
    <div className="h-screen w-screen overflow-hidden flex flex-col md:flex-row bg-slate-50 dark:bg-slate-950">
      {/* Desktop Sidebar Navigation */}
      <aside className="hidden md:flex w-64 flex-col border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shrink-0">
        <div className="h-16 px-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl fz-gradient text-white flex items-center justify-center shrink-0">
              <MessageSquareHeart className="w-5 h-5" />
            </div>
            <span className="font-display font-bold text-lg tracking-tight fz-gradient-text whitespace-nowrap">
              FRIENDZONE
            </span>
          </div>
          <button
            type="button"
            onClick={handleToggleTheme}
            className="w-9 h-9 rounded-xl text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center"
            title={theme === 'dark' ? 'Switch to Light mode' : 'Switch to Dark mode'}
            aria-label="Toggle Light or Dark theme"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-600" />}
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = page === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => navigateTo(item.id)}
                className={`w-full px-3.5 py-2.5 rounded-xl flex items-center justify-between gap-3 text-sm font-medium transition-colors ${
                  active
                    ? 'fz-gradient text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/70'
                }`}
              >
                <span className="flex items-center gap-3 min-w-0">
                  <Icon className="w-4 h-4 shrink-0" />
                  <span className="truncate">{item.label}</span>
                </span>
                {item.badge !== undefined && item.badge > 0 && (
                  <span
                    className={`min-w-[20px] h-5 px-1.5 rounded-full text-[11px] font-mono tabular-nums font-semibold flex items-center justify-center ${
                      active
                        ? 'bg-white text-indigo-700'
                        : 'fz-gradient text-white'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        <div className="p-3 border-t border-slate-200 dark:border-slate-800 space-y-3">
          {/* Light & Dark Theme Switcher */}
          <div
            className="grid grid-cols-2 gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800"
            role="group"
            aria-label="Theme selection"
          >
            <button
              type="button"
              onClick={() => handleSelectTheme('light')}
              className={`py-1.5 px-2.5 rounded-lg text-xs font-medium inline-flex items-center justify-center gap-1.5 transition-colors ${
                theme === 'light'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Sun className="w-3.5 h-3.5 text-amber-500" />
              <span>Light</span>
            </button>
            <button
              type="button"
              onClick={() => handleSelectTheme('dark')}
              className={`py-1.5 px-2.5 rounded-lg text-xs font-medium inline-flex items-center justify-center gap-1.5 transition-colors ${
                theme === 'dark'
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Moon className="w-3.5 h-3.5 text-indigo-400" />
              <span>Dark</span>
            </button>
          </div>

          <div className="flex justify-center">
            <PWAInstallButton compact />
          </div>
          <div className="flex items-center justify-between gap-2 px-2 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800/60">
            <button
              type="button"
              onClick={() => navigateTo('profile')}
              className="flex items-center gap-2.5 min-w-0 text-left"
            >
              <Avatar src={profile.photoURL} name={profile.displayName} size="sm" isOnline showPresence />
              <div className="min-w-0">
                <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                  {profile.displayName}
                </p>
                <p className="text-[11px] font-mono text-slate-500 dark:text-slate-400 truncate">
                  {profile.uniqueCode}
                </p>
              </div>
            </button>
            <button
              type="button"
              onClick={logout}
              className="p-2 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-white dark:hover:bg-slate-800 shrink-0"
              title="Sign Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile Top Bar (<= 56px) */}
      <header className="md:hidden h-14 px-3 border-b border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md flex items-center justify-between shrink-0 z-30">
        <div className="flex items-center gap-2 min-w-0">
          {canGoBack && (
            <button
              type="button"
              onClick={handleBack}
              className="w-10 h-10 rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0"
              aria-label="Go back"
              title="Back"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
          <div className="w-8 h-8 rounded-lg fz-gradient text-white flex items-center justify-center shrink-0">
            <MessageSquareHeart className="w-4 h-4" />
          </div>
          <span className="font-display font-bold text-base fz-gradient-text truncate">FRIENDZONE</span>
        </div>

        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={handleToggleTheme}
            className="w-10 h-10 rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
            aria-label={theme === 'dark' ? 'Switch to Light mode' : 'Switch to Dark mode'}
            title={theme === 'dark' ? 'Light mode' : 'Dark mode'}
          >
            {theme === 'dark' ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-indigo-600" />}
          </button>
          <button
            type="button"
            onClick={() => navigateTo('notifications')}
            className="relative w-10 h-10 rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300"
            aria-label="Notifications"
          >
            <Bell className="w-5 h-5" />
            {unreadNotifsCount > 0 && (
              <span className="absolute top-2 right-2 w-2.5 h-2.5 rounded-full fz-gradient" />
            )}
          </button>
          <button
            type="button"
            onClick={() => setMobileMenuOpen(true)}
            className="w-10 h-10 rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300"
            aria-label="Open menu"
          >
            <Menu className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 min-h-0 overflow-hidden">
        {/* Global Admin Announcement Banner */}
        {appSettings.announcementBanner && (
          <div className="px-4 py-2 bg-indigo-600 text-white text-xs font-medium text-center shrink-0">
            {appSettings.announcementBanner}
          </div>
        )}

        {/* Active Page Viewport */}
        <main className="flex-1 min-h-0 overflow-hidden pb-16 md:pb-0">
          <AnimatePresence mode="wait">
            <motion.div
              key={page}
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.15, ease: [0.16, 1, 0.3, 1] }}
              className="h-full w-full"
            >
              {page === 'home' && (
                <HomePage
                  profile={profile}
                  friends={friends}
                  directChats={directChats}
                  groups={userGroups}
                  notifications={notifications}
                  onNavigate={navigateTo}
                  onOpenChat={handleOpenChat}
                  onOpenGroup={handleOpenGroup}
                />
              )}

              {page === 'chats' && (
                <MyChatsPage
                  profile={profile}
                  friends={friends}
                  directChats={directChats}
                  usersById={usersById}
                  selectedChatId={selectedChatId}
                  onSelectChat={setSelectedChatId}
                  onBack={handleBack}
                  maxFileSizeMB={appSettings.maxFileSizeMB}
                  isPlatformAdmin={isAdmin}
                />
              )}

              {page === 'groups' && (
                <GroupsPage
                  profile={profile}
                  friends={friends}
                  userGroups={userGroups}
                  selectedGroupId={selectedGroupId}
                  onSelectGroup={setSelectedGroupId}
                  onBack={handleBack}
                  allowGroupCreation={appSettings.allowGroupCreation}
                  maxGroupSize={appSettings.maxGroupSize}
                  maxFileSizeMB={appSettings.maxFileSizeMB}
                  isPlatformAdmin={isAdmin}
                />
              )}

              {page === 'friends' && (
                <AddFriendsPage
                  profile={profile}
                  friendships={friendships}
                  friends={friends}
                  savedContacts={savedContacts}
                  usersById={usersById}
                  onOpenChat={handleOpenChat}
                  onBack={handleBack}
                />
              )}

              {page === 'notifications' && (
                <NotificationsPage
                  notifications={notifications}
                  privateData={privateData}
                  onUpdatePrivatePrefs={async (updates) => {
                    const { updateDoc, serverTimestamp } = await import('firebase/firestore');
                    await updateDoc(doc(db, 'userPrivate', profile.uid), {
                      ...updates,
                      updatedAt: serverTimestamp(),
                    });
                  }}
                  onNavigate={navigateTo}
                  onOpenChat={handleOpenChat}
                  onOpenGroup={handleOpenGroup}
                  onBack={handleBack}
                />
              )}

              {page === 'profile' && <ProfilePage onBack={handleBack} />}
              {page === 'settings' && <SettingsPage onBack={handleBack} />}
              {page === 'admin' && <AdminPanelPage onBack={handleBack} />}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* Mobile Bottom Tab Bar (<= 64px) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-30 h-16 pb-safe bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 grid grid-cols-5 items-center">
        {[
          { id: 'home' as PageRoute, label: 'Home', icon: Home },
          { id: 'chats' as PageRoute, label: 'Chats', icon: MessageCircle, badge: unreadChatsCount },
          { id: 'groups' as PageRoute, label: 'Groups', icon: Users },
          { id: 'friends' as PageRoute, label: 'Friends', icon: UserPlus },
          { id: 'profile' as PageRoute, label: 'Profile', icon: User },
        ].map((tab) => {
          const Icon = tab.icon;
          const active = page === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => navigateTo(tab.id)}
              className={`relative flex flex-col items-center justify-center h-full min-h-[44px] ${
                active ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[10px] font-medium mt-1">{tab.label}</span>
              {tab.badge !== undefined && tab.badge > 0 && (
                <span className="absolute top-1.5 right-3 min-w-[16px] h-4 px-1 rounded-full fz-gradient text-white text-[10px] font-mono font-bold flex items-center justify-center">
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Mobile Full Menu Sheet */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex justify-end">
          <div className="w-72 h-full bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
                <span className="font-display font-bold text-base fz-gradient-text">Menu</span>
                <button
                  type="button"
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-2 rounded-lg text-slate-500"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="mt-4 space-y-1">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => navigateTo(item.id)}
                      className={`w-full px-3.5 py-3 rounded-xl flex items-center justify-between text-sm font-medium ${
                        page === item.id
                          ? 'fz-gradient text-white'
                          : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      <span className="flex items-center gap-3">
                        <Icon className="w-4 h-4" />
                        <span>{item.label}</span>
                      </span>
                      {item.badge !== undefined && item.badge > 0 && (
                        <span className="text-xs font-mono tabular-nums">{item.badge}</span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="space-y-3 pt-4 border-t border-slate-200 dark:border-slate-800">
              <div
                className="grid grid-cols-2 gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800"
                role="group"
                aria-label="Theme selection"
              >
                <button
                  type="button"
                  onClick={() => handleSelectTheme('light')}
                  className={`py-2 px-2.5 rounded-lg text-xs font-medium inline-flex items-center justify-center gap-1.5 transition-colors ${
                    theme === 'light'
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <Sun className="w-3.5 h-3.5 text-amber-500" />
                  <span>Light</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleSelectTheme('dark')}
                  className={`py-2 px-2.5 rounded-lg text-xs font-medium inline-flex items-center justify-center gap-1.5 transition-colors ${
                    theme === 'dark'
                      ? 'bg-slate-900 text-white shadow-sm'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <Moon className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Dark</span>
                </button>
              </div>
              <div className="flex justify-center">
                <PWAInstallButton compact />
              </div>
              <button
                type="button"
                onClick={logout}
                className="w-full py-2.5 rounded-xl border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400 text-sm font-medium flex items-center justify-center gap-2"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Real-time Notification Toast */}
      {toastAlert && (
        <div className="fixed top-4 right-4 z-50 max-w-xs w-full rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-lg p-4 flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl fz-gradient text-white flex items-center justify-center shrink-0">
            <Bell className="w-4 h-4" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">
              {toastAlert.title}
            </p>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400 line-clamp-2">
              {toastAlert.body}
            </p>
          </div>
          <button
            type="button"
            onClick={() => setToastAlert(null)}
            className="text-slate-400 hover:text-slate-600"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      <OfflineIndicator />
    </div>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider>
        <AuthProvider>
          <WorkspaceShell />
        </AuthProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
