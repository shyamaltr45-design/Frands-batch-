import React, { useEffect, useRef, useState } from 'react';
import { ArrowLeft, Camera, Check, Copy, LogOut, Save, ShieldCheck } from 'lucide-react';
import { Avatar } from '../components/Avatar';
import { useAuth } from '../contexts/AuthContext';
import { uploadMediaFile } from '../lib/firebase';
import { DEMO_ASSETS } from '../lib/utils';

interface ProfilePageProps {
  onBack?: () => void;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({ onBack }) => {
  const { firebaseUser, profile, privateData, isAdmin, isSuperAdmin, updateMyProfile, logout, appSettings } =
    useAuth();

  const [displayName, setDisplayName] = useState(profile?.displayName || '');
  const [bio, setBio] = useState(profile?.bio || '');
  const [photoURL, setPhotoURL] = useState(profile?.photoURL || '');
  const [phoneNumber, setPhoneNumber] = useState(privateData?.phoneNumber || '');
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (profile) {
      setDisplayName(profile.displayName || '');
      setBio(profile.bio || '');
      setPhotoURL(profile.photoURL || '');
    }
  }, [profile]);

  useEffect(() => {
    if (privateData) {
      setPhoneNumber(privateData.phoneNumber || '');
    }
  }, [privateData]);

  if (!profile) return null;

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setErrorMsg(null);
    setUploading(true);
    try {
      const res = await uploadMediaFile(`avatars/${profile.uid}`, file, appSettings.maxFileSizeMB);
      setPhotoURL(res.url);
      await updateMyProfile({ photoURL: res.url });
      setStatusMsg('Profile picture updated.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to upload profile picture.');
    } finally {
      setUploading(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setErrorMsg(null);
    setStatusMsg(null);
    try {
      await updateMyProfile({ displayName, bio, photoURL, phoneNumber });
      setStatusMsg('Profile changes saved.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to update profile.');
    } finally {
      setSaving(false);
    }
  };

  const handleCopyId = async () => {
    try {
      await navigator.clipboard.writeText(profile.uniqueCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Ignore
    }
  };

  return (
    <div className="h-full overflow-y-auto p-4 sm:p-6 lg:p-8">
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            {onBack && (
              <button
                type="button"
                onClick={onBack}
                className="mt-0.5 w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0"
                aria-label="Back"
                title="Back"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            )}
            <div>
              <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
                My Profile
              </h1>
              <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
                Manage how friends see you across FRIENDZONE chats and groups.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={logout}
            className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-sm font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 inline-flex items-center gap-2 min-h-[40px]"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>

        {/* Profile Overview Card */}
        <section className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 sm:p-8">
          <div className="flex flex-col sm:flex-row sm:items-center gap-6">
            <div className="relative inline-block self-start">
              <Avatar
                src={photoURL || profile.photoURL}
                name={displayName || profile.displayName}
                size="xl"
                isOnline={profile.isOnline}
                showPresence
              />
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handlePhotoUpload}
                className="hidden"
              />
              <button
                type="button"
                disabled={uploading}
                onClick={() => fileInputRef.current?.click()}
                className="absolute -bottom-1 -right-1 w-9 h-9 rounded-full fz-gradient text-white flex items-center justify-center shadow-md ring-2 ring-white dark:ring-slate-900 hover:opacity-95"
                title="Upload profile picture"
              >
                <Camera className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-1.5 flex-1 min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="font-display text-xl font-bold text-slate-900 dark:text-white">
                  {profile.displayName}
                </h2>
                {isAdmin && (
                  <span className="inline-flex items-center gap-1 text-xs font-medium text-indigo-600 dark:text-indigo-400">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>{isSuperAdmin ? 'Super Admin' : 'Admin'}</span>
                  </span>
                )}
              </div>
              <p className="text-sm text-slate-500 dark:text-slate-400 truncate">
                {firebaseUser?.email || 'Verified Member'}
              </p>

              <div className="pt-2 flex flex-wrap items-center gap-3">
                <div className="inline-flex items-center gap-2 rounded-xl bg-slate-100 dark:bg-slate-800 px-3 py-1.5">
                  <span className="text-xs text-slate-500 dark:text-slate-400">User ID:</span>
                  <span className="font-mono text-xs font-semibold text-slate-900 dark:text-white">
                    {profile.uniqueCode}
                  </span>
                  <button
                    type="button"
                    onClick={handleCopyId}
                    className="text-indigo-600 dark:text-indigo-400 hover:opacity-80"
                    title="Copy Unique User ID"
                  >
                    {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <span className="text-xs text-slate-400 font-mono truncate">
                  UID: {profile.uid}
                </span>
              </div>
            </div>
          </div>

          {statusMsg && (
            <div className="mt-5 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 px-4 py-3 text-xs text-emerald-700 dark:text-emerald-300">
              {statusMsg}
            </div>
          )}

          {errorMsg && (
            <div className="mt-5 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 px-4 py-3 text-xs text-rose-700 dark:text-rose-300">
              {errorMsg}
            </div>
          )}

          <form onSubmit={handleSave} className="mt-6 space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Display Name
              </label>
              <input
                type="text"
                required
                maxLength={80}
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-4 py-2.5 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Phone Number (lets friends add you by name &amp; number)
              </label>
              <input
                type="tel"
                maxLength={24}
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                placeholder="+880 1712-345678"
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-4 py-2.5 text-sm font-mono text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Bio
              </label>
              <textarea
                rows={3}
                maxLength={280}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="Tell your friends a little about yourself..."
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-4 py-2.5 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Avatar Image URL (or upload via camera icon above)
              </label>
              <input
                type="url"
                maxLength={2048}
                value={photoURL}
                onChange={(e) => setPhotoURL(e.target.value)}
                placeholder="https://..."
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-4 py-2.5 text-sm text-slate-900 dark:text-white"
              />
              <div className="mt-2 flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                <span>Quick presets:</span>
                <button
                  type="button"
                  onClick={() => setPhotoURL(DEMO_ASSETS.avatarMaya)}
                  className="text-indigo-600 dark:text-indigo-400 hover:underline"
                >
                  Portrait A
                </button>
                <span>·</span>
                <button
                  type="button"
                  onClick={() => setPhotoURL(DEMO_ASSETS.avatarMarcus)}
                  className="text-indigo-600 dark:text-indigo-400 hover:underline"
                >
                  Portrait B
                </button>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                disabled={saving || uploading}
                className="rounded-xl fz-gradient px-5 py-2.5 text-sm font-semibold text-white hover:opacity-95 disabled:opacity-50 inline-flex items-center gap-2 min-h-[44px]"
              >
                <Save className="w-4 h-4" />
                <span>{saving ? 'Saving...' : 'Save Profile'}</span>
              </button>
            </div>
          </form>
        </section>
      </div>
    </div>
  );
};
