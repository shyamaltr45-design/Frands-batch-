import React, { useState } from 'react';
import { ArrowLeft, Bell, Check, ChevronDown, ChevronUp, Database, Moon, Smartphone, Sun } from 'lucide-react';
import { PWAInstallButton } from '../components/PWAInstallButton';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { firebaseProjectConfig, requestPushMessagingToken } from '../lib/firebase';

interface SettingsPageProps {
  onBack?: () => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({ onBack }) => {
  const { theme, setTheme } = useTheme();
  const { privateData, updatePrivatePrefs } = useAuth();
  const [showFirebaseGuide, setShowFirebaseGuide] = useState(false);
  const [savedNotice, setSavedNotice] = useState<string | null>(null);

  const handleThemeSelect = async (mode: 'light' | 'dark') => {
    setTheme(mode);
    await updatePrivatePrefs({ themePreference: mode });
    setSavedNotice(`Theme switched to ${mode} mode.`);
    setTimeout(() => setSavedNotice(null), 2500);
  };

  const handleToggleNotifications = async () => {
    const next = !(privateData?.notificationsEnabled ?? true);
    if (next && typeof Notification !== 'undefined') {
      await Notification.requestPermission();
      const vapid = import.meta.env.VITE_FIREBASE_VAPID_KEY as string | undefined;
      const token = await requestPushMessagingToken(vapid);
      await updatePrivatePrefs({
        notificationsEnabled: true,
        ...(token ? { fcmToken: token } : {}),
      });
    } else {
      await updatePrivatePrefs({ notificationsEnabled: next });
    }
    setSavedNotice(next ? 'Notifications enabled.' : 'Notifications muted.');
    setTimeout(() => setSavedNotice(null), 2500);
  };

  return (
    <div className="h-full overflow-y-auto p-4 sm:p-6 lg:p-8">
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="flex items-start gap-3">
          {onBack && (
            <button
              type="button"
              onClick={onBack}
              className="mt-0.5 w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0"
              aria-label="Back"
              title="Back"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          )}
          <div>
            <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
              Settings
            </h1>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              Customize appearance, push notifications, app installation, and Firebase setup.
            </p>
          </div>
        </div>

        {savedNotice && (
          <div className="rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 px-4 py-3 text-xs text-emerald-700 dark:text-emerald-300 flex items-center gap-2">
            <Check className="w-4 h-4" />
            <span>{savedNotice}</span>
          </div>
        )}

        {/* Appearance */}
        <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
            Appearance
          </h2>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Choose Light Mode or Dark Mode for FRIENDZONE.
          </p>
          <div className="mt-4 grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => handleThemeSelect('light')}
              className={`p-4 rounded-2xl border text-left transition-colors flex items-center gap-3 ${
                theme === 'light'
                  ? 'border-indigo-600 bg-indigo-50/70 dark:bg-indigo-950/40'
                  : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60'
              }`}
            >
              <Sun className="w-5 h-5 text-amber-500" />
              <div>
                <p className="text-sm font-semibold text-slate-900 dark:text-white">Light Mode</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Crisp daylight canvas</p>
              </div>
            </button>

            <button
              type="button"
              onClick={() => handleThemeSelect('dark')}
              className={`p-4 rounded-2xl border text-left transition-colors flex items-center gap-3 ${
                theme === 'dark'
                  ? 'border-indigo-600 bg-indigo-50/70 dark:bg-indigo-950/40'
                  : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60'
              }`}
            >
              <Moon className="w-5 h-5 text-indigo-500" />
              <div>
                <p className="text-sm font-semibold text-slate-900 dark:text-white">Dark Mode</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Deep slate contrast</p>
              </div>
            </button>
          </div>
        </section>

        {/* Notifications */}
        <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 flex items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <Bell className="w-5 h-5 text-indigo-600 dark:text-indigo-400 mt-0.5" />
            <div>
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                Real-Time & Push Notifications
              </h2>
              <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                Receive desktop and mobile alerts for incoming messages, friend requests, and group updates.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleToggleNotifications}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-colors shrink-0 min-h-[40px] ${
              privateData?.notificationsEnabled
                ? 'fz-gradient text-white'
                : 'border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
            }`}
          >
            {privateData?.notificationsEnabled ? 'Enabled' : 'Disabled'}
          </button>
        </section>

        {/* PWA Installation */}
        <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <Smartphone className="w-5 h-5 text-purple-600 dark:text-purple-400 mt-0.5" />
            <div>
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                Install FRIENDZONE App (PWA)
              </h2>
              <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                Install on Android, iPhone, iPad, or Desktop for full-screen standalone messaging.
              </p>
            </div>
          </div>
          <PWAInstallButton />
        </section>

        {/* Firebase Configuration Instructions */}
        <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden">
          <button
            type="button"
            onClick={() => setShowFirebaseGuide((v) => !v)}
            className="w-full p-6 flex items-center justify-between text-left hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors"
          >
            <div className="flex items-center gap-3">
              <Database className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              <div>
                <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                  Firebase Configuration Guide
                </h2>
                <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
                  Connected Project: <span className="font-mono">{firebaseProjectConfig.projectId}</span>
                </p>
              </div>
            </div>
            {showFirebaseGuide ? (
              <ChevronUp className="w-4 h-4 text-slate-400" />
            ) : (
              <ChevronDown className="w-4 h-4 text-slate-400" />
            )}
          </button>

          {showFirebaseGuide && (
            <div className="px-6 pb-6 pt-2 border-t border-slate-100 dark:border-slate-800 space-y-4 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              <div>
                <p className="font-semibold text-slate-900 dark:text-white">
                  1. Authentication Providers (Firebase Console)
                </p>
                <p className="mt-1">
                  Google Sign-In is pre-configured. To enable Email &amp; Password registration and login, open Firebase Console → Project <span className="font-mono">{firebaseProjectConfig.projectId}</span> → Authentication → Sign-in method → Enable <strong>Email/Password</strong>.
                </p>
              </div>
              <div>
                <p className="font-semibold text-slate-900 dark:text-white">
                  2. Cloud Firestore &amp; Security Rules
                </p>
                <p className="mt-1">
                  Database ID <span className="font-mono">{firebaseProjectConfig.firestoreDatabaseId}</span> is provisioned with hardened rules from <span className="font-mono">firestore.rules</span> enforcing user profile ownership, private group membership gates, and admin RBAC.
                </p>
              </div>
              <div>
                <p className="font-semibold text-slate-900 dark:text-white">
                  3. Firebase Storage for Profile &amp; Chat Media
                </p>
                <p className="mt-1">
                  Bucket <span className="font-mono">{firebaseProjectConfig.storageBucket}</span> is wired for image and file uploads. Deploy the included <span className="font-mono">storage.rules</span> file in Firebase Console → Storage → Rules.
                </p>
              </div>
              <div>
                <p className="font-semibold text-slate-900 dark:text-white">
                  4. Firebase Cloud Messaging (FCM)
                </p>
                <p className="mt-1">
                  Generate a Web Push certificate key pair in Firebase Console → Project Settings → Cloud Messaging and set <span className="font-mono">VITE_FIREBASE_VAPID_KEY</span> in your environment for background push token registration via <span className="font-mono">/firebase-messaging-sw.js</span>.
                </p>
              </div>
            </div>
          )}
        </section>
      </div>
    </div>
  );
};
