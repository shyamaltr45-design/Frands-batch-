import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  Crown,
  Info,
  LogOut,
  Plus,
  Search,
  Shield,
  Trash2,
  Upload,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import {
  collection,
  doc,
  onSnapshot,
  orderBy,
  query,
} from 'firebase/firestore';
import { Avatar } from '../components/Avatar';
import { ChatThread } from '../components/ChatThread';
import { db, handleFirestoreError, OperationType, uploadMediaFile } from '../lib/firebase';
import { formatRelativeTime } from '../lib/utils';
import {
  addMemberToGroup,
  createGroup,
  deleteEntireGroup,
  deleteGroupMessage,
  lookupUserByUniqueCode,
  markGroupRead,
  removeGroupMember,
  sendGroupMessage,
  setGroupMemberRole,
  updateGroupDetails,
} from '../services/chatService';
import { ChatMessage, Group, GroupMember, UserGroupSummary, UserProfile } from '../types';

interface GroupsPageProps {
  profile: UserProfile;
  friends: UserProfile[];
  userGroups: UserGroupSummary[];
  selectedGroupId: string | null;
  onSelectGroup: (groupId: string | null) => void;
  onBack?: () => void;
  allowGroupCreation: boolean;
  maxGroupSize: number;
  maxFileSizeMB: number;
  isPlatformAdmin: boolean;
}

export const GroupsPage: React.FC<GroupsPageProps> = ({
  profile,
  friends,
  userGroups,
  selectedGroupId,
  onSelectGroup,
  onBack,
  allowGroupCreation,
  maxGroupSize,
  maxFileSizeMB,
  isPlatformAdmin,
}) => {
  const [search, setSearch] = useState('');
  const [groupDocs, setGroupDocs] = useState<Record<string, Group>>({});
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [members, setMembers] = useState<GroupMember[]>([]);
  const [showInfoDrawer, setShowInfoDrawer] = useState(false);

  // Create Group Modal
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newPhoto, setNewPhoto] = useState('');
  const [selectedFriendIds, setSelectedFriendIds] = useState<string[]>([]);
  const [creating, setCreating] = useState(false);
  const [createError, setCreateError] = useState<string | null>(null);

  // Add Member by Unique Code
  const [inviteCode, setInviteCode] = useState('');
  const [inviteFeedback, setInviteFeedback] = useState<string | null>(null);

  // Edit Group Form
  const [editMode, setEditMode] = useState(false);
  const [editName, setEditName] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const [editPhoto, setEditPhoto] = useState('');

  const createPhotoInputRef = useRef<HTMLInputElement>(null);
  const editPhotoInputRef = useRef<HTMLInputElement>(null);

  // Subscribe to live Group documents for each membership
  useEffect(() => {
    if (userGroups.length === 0) {
      setGroupDocs({});
      return;
    }
    const unsubs = userGroups.map((ug) =>
      onSnapshot(
        doc(db, 'groups', ug.groupId),
        (snap) => {
          if (snap.exists()) {
            setGroupDocs((prev) => ({ ...prev, [ug.groupId]: snap.data() as Group }));
          }
        },
        () => {}
      )
    );
    return () => unsubs.forEach((u) => u());
  }, [userGroups]);

  const activeGroup = selectedGroupId ? groupDocs[selectedGroupId] || null : null;
  const myMembership = members.find((m) => m.uid === profile.uid);
  const isGroupAdmin = myMembership?.role === 'admin' || isPlatformAdmin;

  // Subscribe to messages and members for selected group
  useEffect(() => {
    if (!selectedGroupId) {
      setMessages([]);
      setMembers([]);
      return;
    }

    markGroupRead(profile.uid, selectedGroupId).catch(() => {});

    const msgsPath = `groups/${selectedGroupId}/messages`;
    const unsubMsgs = onSnapshot(
      query(collection(db, msgsPath), orderBy('createdAt', 'asc')),
      (snap) => setMessages(snap.docs.map((d) => d.data() as ChatMessage)),
      (err) => handleFirestoreError(err, OperationType.LIST, msgsPath)
    );

    const memsPath = `groups/${selectedGroupId}/members`;
    const unsubMems = onSnapshot(
      collection(db, memsPath),
      (snap) => setMembers(snap.docs.map((d) => d.data() as GroupMember)),
      (err) => handleFirestoreError(err, OperationType.LIST, memsPath)
    );

    return () => {
      unsubMsgs();
      unsubMems();
    };
  }, [selectedGroupId, profile.uid]);

  useEffect(() => {
    if (selectedGroupId) {
      markGroupRead(profile.uid, selectedGroupId).catch(() => {});
    }
  }, [messages.length]);

  const filteredSummaries = userGroups.filter((ug) => {
    const liveName = groupDocs[ug.groupId]?.name || ug.name;
    return !search.trim() || liveName.toLowerCase().includes(search.toLowerCase());
  });

  const handleUploadGroupPhoto = async (
    e: React.ChangeEvent<HTMLInputElement>,
    setter: (url: string) => void
  ) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    try {
      const res = await uploadMediaFile(`groups/${profile.uid}`, file, maxFileSizeMB);
      setter(res.url);
    } catch (err) {
      setCreateError(err instanceof Error ? err.message : 'Photo upload failed.');
    }
  };

  const handleCreateGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreateError(null);
    setCreating(true);
    try {
      const initialMembers = friends.filter((f) => selectedFriendIds.includes(f.uid));
      const grpId = await createGroup({
        creator: profile,
        name: newName,
        description: newDesc,
        photoURL: newPhoto,
        initialMembers,
      });
      setShowCreateModal(false);
      setNewName('');
      setNewDesc('');
      setNewPhoto('');
      setSelectedFriendIds([]);
      onSelectGroup(grpId);
    } catch (err) {
      setCreateError(err instanceof Error ? err.message : 'Could not create group.');
    } finally {
      setCreating(false);
    }
  };

  const handleInviteByCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeGroup) return;
    setInviteFeedback(null);
    if (members.length >= maxGroupSize) {
      setInviteFeedback(`Group reached maximum limit of ${maxGroupSize} members.`);
      return;
    }
    try {
      const targetUser = await lookupUserByUniqueCode(inviteCode);
      if (!targetUser) {
        setInviteFeedback('No user found with that Unique User ID.');
        return;
      }
      await addMemberToGroup(activeGroup, profile, targetUser);
      setInviteCode('');
      setInviteFeedback(`${targetUser.displayName} added to the group.`);
    } catch (err) {
      setInviteFeedback(err instanceof Error ? err.message : 'Could not add user.');
    }
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeGroup) return;
    await updateGroupDetails(activeGroup.id, {
      name: editName,
      description: editDesc,
      photoURL: editPhoto,
    });
    setEditMode(false);
  };

  return (
    <div className="h-full flex overflow-hidden bg-white dark:bg-slate-900">
      {/* Left Group Sidebar */}
      <aside
        className={`${
          selectedGroupId ? 'hidden md:flex' : 'flex'
        } w-full md:w-80 lg:w-96 flex-col border-r border-slate-200 dark:border-slate-800 shrink-0`}
      >
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              {onBack && (
                <button
                  type="button"
                  onClick={onBack}
                  className="w-9 h-9 -ml-1 rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0"
                  aria-label="Back"
                  title="Back"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
              )}
              <h1 className="font-display text-lg font-bold text-slate-900 dark:text-white truncate">
                Groups
              </h1>
            </div>
            {allowGroupCreation && (
              <button
                type="button"
                onClick={() => setShowCreateModal(true)}
                className="inline-flex items-center gap-1.5 rounded-xl fz-gradient px-3 py-2 text-xs font-semibold text-white hover:opacity-95 transition-opacity min-h-[40px] shrink-0"
              >
                <Plus className="w-4 h-4" />
                <span>New Group</span>
              </button>
            )}
          </div>

          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search groups..."
              className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 pl-10 pr-3 py-2 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/70">
          {filteredSummaries.length === 0 ? (
            <div className="p-8 text-center">
              <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
                No groups found
              </p>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Create a new group and invite friends using their unique User ID.
              </p>
            </div>
          ) : (
            filteredSummaries.map((ug) => {
              const live = groupDocs[ug.groupId];
              const displayName = live?.name || ug.name;
              const displayPhoto = live?.photoURL ?? ug.photoURL;
              const hasUnread =
                !!live?.lastMessageAt &&
                !!ug.lastReadAt &&
                live.lastMessageAt.toMillis() > ug.lastReadAt.toMillis() &&
                selectedGroupId !== ug.groupId;

              return (
                <button
                  key={ug.groupId}
                  type="button"
                  onClick={() => {
                    onSelectGroup(ug.groupId);
                    setShowInfoDrawer(false);
                  }}
                  className={`w-full text-left px-4 py-3.5 flex items-center gap-3 transition-colors min-h-[68px] ${
                    selectedGroupId === ug.groupId
                      ? 'bg-indigo-50/90 dark:bg-indigo-950/40'
                      : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
                  }`}
                >
                  <Avatar src={displayPhoto} name={displayName} isGroup />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                        {displayName}
                      </p>
                      <span className="text-[11px] font-mono tabular-nums text-slate-400 shrink-0">
                        {formatRelativeTime(live?.lastMessageAt || ug.joinedAt)}
                      </span>
                    </div>
                    <div className="mt-0.5 flex items-center justify-between gap-2">
                      <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                        {live?.lastMessage || 'Group created'}
                      </p>
                      {hasUnread && (
                        <span className="w-2.5 h-2.5 rounded-full fz-gradient shrink-0" />
                      )}
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </aside>

      {/* Main Group Thread */}
      <section className={`${selectedGroupId ? 'flex' : 'hidden md:flex'} flex-1 flex-col min-w-0`}>
        {activeGroup ? (
          <>
            <header className="h-16 px-4 sm:px-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 bg-white dark:bg-slate-900 shrink-0">
              <div className="flex items-center gap-3 min-w-0">
                <button
                  type="button"
                  onClick={() => onSelectGroup(null)}
                  className="w-10 h-10 -ml-2 rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                  aria-label="Back to groups"
                  title="Back to groups"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <Avatar src={activeGroup.photoURL} name={activeGroup.name} isGroup />
                <div className="min-w-0">
                  <h2 className="font-display text-sm sm:text-base font-semibold text-slate-900 dark:text-white truncate">
                    {activeGroup.name}
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 truncate tabular-nums">
                    {members.length || activeGroup.memberCount} members
                    {activeGroup.description ? ` · ${activeGroup.description}` : ''}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowInfoDrawer((v) => !v)}
                className={`w-10 h-10 rounded-xl border flex items-center justify-center transition-colors shrink-0 ${
                  showInfoDrawer
                    ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400'
                    : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
                title="Group details and members"
              >
                <Info className="w-4 h-4" />
              </button>
            </header>

            <div className="flex-1 flex min-h-0 overflow-hidden">
              <div className="flex-1 min-w-0 min-h-0">
                <ChatThread
                  messages={messages}
                  currentUser={profile}
                  isGroupChat
                  canDeleteAny={isGroupAdmin}
                  storageFolder={`groups/${activeGroup.id}`}
                  maxFileSizeMB={maxFileSizeMB}
                  reportContextPrefix={`groups/${activeGroup.id}/messages`}
                  onSendMessage={async (payload) => {
                    await sendGroupMessage({
                      group: activeGroup,
                      sender: profile,
                      members,
                      ...payload,
                    });
                  }}
                  onDeleteMessage={async (msgId) => {
                    await deleteGroupMessage(activeGroup.id, msgId);
                  }}
                />
              </div>

              {/* Group Info & Members Drawer */}
              {showInfoDrawer && (
                <aside className="w-80 border-l border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-y-auto p-5 space-y-6 shrink-0">
                  <div className="flex items-center justify-between">
                    <h3 className="font-display text-sm font-semibold text-slate-900 dark:text-white">
                      Group Details
                    </h3>
                    <button
                      type="button"
                      onClick={() => setShowInfoDrawer(false)}
                      className="p-1.5 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {!editMode ? (
                    <div className="text-center space-y-2">
                      <div className="flex justify-center">
                        <Avatar src={activeGroup.photoURL} name={activeGroup.name} size="xl" isGroup />
                      </div>
                      <h4 className="font-display text-base font-bold text-slate-900 dark:text-white">
                        {activeGroup.name}
                      </h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {activeGroup.description || 'No description provided.'}
                      </p>
                      {isGroupAdmin && (
                        <button
                          type="button"
                          onClick={() => {
                            setEditName(activeGroup.name);
                            setEditDesc(activeGroup.description);
                            setEditPhoto(activeGroup.photoURL);
                            setEditMode(true);
                          }}
                          className="mt-2 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
                        >
                          Edit Group Info
                        </button>
                      )}
                    </div>
                  ) : (
                    <form onSubmit={handleSaveEdit} className="space-y-3">
                      <input
                        ref={editPhotoInputRef}
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleUploadGroupPhoto(e, setEditPhoto)}
                        className="hidden"
                      />
                      <button
                        type="button"
                        onClick={() => editPhotoInputRef.current?.click()}
                        className="w-full py-2 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 text-xs font-medium text-slate-600 dark:text-slate-300 flex items-center justify-center gap-2"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        <span>Upload Group Photo</span>
                      </button>
                      <input
                        type="text"
                        required
                        maxLength={80}
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-sm text-slate-900 dark:text-white"
                      />
                      <textarea
                        rows={2}
                        maxLength={400}
                        value={editDesc}
                        onChange={(e) => setEditDesc(e.target.value)}
                        className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-sm text-slate-900 dark:text-white"
                      />
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => setEditMode(false)}
                          className="flex-1 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="flex-1 py-2 rounded-xl fz-gradient text-white text-xs font-semibold"
                        >
                          Save
                        </button>
                      </div>
                    </form>
                  )}

                  {/* Add Member by Unique User ID */}
                  {isGroupAdmin && (
                    <div className="pt-4 border-t border-slate-200 dark:border-slate-800">
                      <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                        Add Member by User ID
                      </p>
                      <form onSubmit={handleInviteByCode} className="flex gap-2">
                        <input
                          type="text"
                          value={inviteCode}
                          onChange={(e) => setInviteCode(e.target.value)}
                          placeholder="FZ-XXXXXX"
                          className="flex-1 min-w-0 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-xs font-mono text-slate-900 dark:text-white uppercase"
                        />
                        <button
                          type="submit"
                          className="px-3 py-2 rounded-xl fz-gradient text-white text-xs font-medium shrink-0"
                          title="Add member"
                        >
                          <UserPlus className="w-4 h-4" />
                        </button>
                      </form>
                      {inviteFeedback && (
                        <p className="mt-2 text-xs text-indigo-600 dark:text-indigo-400">
                          {inviteFeedback}
                        </p>
                      )}

                      {friends.filter((f) => !members.some((m) => m.uid === f.uid)).length > 0 && (
                        <div className="mt-3">
                          <p className="text-[11px] text-slate-500 dark:text-slate-400 mb-1.5">
                            Quick add from friends
                          </p>
                          <div className="space-y-1 max-h-32 overflow-y-auto">
                            {friends
                              .filter((f) => !members.some((m) => m.uid === f.uid))
                              .map((f) => (
                                <button
                                  key={f.uid}
                                  type="button"
                                  onClick={() => addMemberToGroup(activeGroup, profile, f)}
                                  className="w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-xs text-slate-700 dark:text-slate-200"
                                >
                                  <span className="truncate">{f.displayName}</span>
                                  <Plus className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                                </button>
                              ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Member List */}
                  <div className="pt-4 border-t border-slate-200 dark:border-slate-800">
                    <p className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-3 tabular-nums">
                      Members ({members.length})
                    </p>
                    <div className="space-y-2.5">
                      {members.map((m) => (
                        <div key={m.uid} className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2.5 min-w-0">
                            <Avatar src={m.photoURL} name={m.displayName} size="sm" />
                            <div className="min-w-0">
                              <p className="text-xs font-medium text-slate-900 dark:text-white truncate">
                                {m.displayName} {m.uid === profile.uid ? '(You)' : ''}
                              </p>
                              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                                {m.role === 'admin' ? 'Admin' : 'Member'}
                              </p>
                            </div>
                          </div>

                          {isGroupAdmin && m.uid !== profile.uid && (
                            <div className="flex items-center gap-1 shrink-0">
                              <button
                                type="button"
                                onClick={() =>
                                  setGroupMemberRole(
                                    activeGroup.id,
                                    m.uid,
                                    m.role === 'admin' ? 'member' : 'admin'
                                  )
                                }
                                title={m.role === 'admin' ? 'Demote to Member' : 'Promote to Group Admin'}
                                className={`p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 ${
                                  m.role === 'admin' ? 'text-indigo-600' : 'text-slate-400'
                                }`}
                              >
                                {m.role === 'admin' ? (
                                  <Crown className="w-3.5 h-3.5" />
                                ) : (
                                  <Shield className="w-3.5 h-3.5" />
                                )}
                              </button>
                              <button
                                type="button"
                                onClick={() => removeGroupMember(activeGroup, m.uid)}
                                title="Remove from group"
                                className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800"
                              >
                                <X className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Leave or Delete Group */}
                  <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-2">
                    <button
                      type="button"
                      onClick={async () => {
                        await removeGroupMember(activeGroup, profile.uid);
                        onSelectGroup(null);
                      }}
                      className="w-full py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center justify-center gap-2"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>Leave Group</span>
                    </button>

                    {isGroupAdmin && (
                      <button
                        type="button"
                        onClick={async () => {
                          await deleteEntireGroup(activeGroup.id);
                          onSelectGroup(null);
                        }}
                        className="w-full py-2.5 px-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-xs font-medium text-rose-700 dark:text-rose-300 hover:bg-rose-100 dark:hover:bg-rose-900/50 flex items-center justify-center gap-2"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Delete Group</span>
                      </button>
                    )}
                  </div>
                </aside>
              )}
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-slate-50/50 dark:bg-slate-950/40">
            <Users className="w-10 h-10 text-indigo-500 mb-3" />
            <h2 className="font-display text-lg font-semibold text-slate-800 dark:text-slate-200">
              Select or create a group
            </h2>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400 max-w-sm">
              Choose a group conversation from the sidebar or create a new group room for your friends.
            </p>
          </div>
        )}
      </section>

      {/* Create Group Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleCreateGroup}
            className="w-full max-w-lg rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-xl max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg font-bold text-slate-900 dark:text-white">
                Create New Group
              </h2>
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="p-2 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {createError && (
              <div className="mt-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 p-3 text-xs text-rose-700 dark:text-rose-300">
                {createError}
              </div>
            )}

            <div className="mt-5 space-y-4">
              <div className="flex items-center gap-4">
                <Avatar src={newPhoto} name={newName || 'Group'} size="lg" isGroup />
                <div>
                  <input
                    ref={createPhotoInputRef}
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleUploadGroupPhoto(e, setNewPhoto)}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => createPhotoInputRef.current?.click()}
                    className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 inline-flex items-center gap-2"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Upload Group Picture</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Group Name
                </label>
                <input
                  type="text"
                  required
                  maxLength={80}
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="Design Guild, Study Group, Trip 2026..."
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3.5 py-2.5 text-sm text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Description
                </label>
                <textarea
                  rows={2}
                  maxLength={400}
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  placeholder="What is this group about?"
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3.5 py-2.5 text-sm text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Add Friends ({selectedFriendIds.length} selected)
                </label>
                {friends.length === 0 ? (
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    You can add members anytime later using their Unique User ID.
                  </p>
                ) : (
                  <div className="max-h-40 overflow-y-auto border border-slate-200 dark:border-slate-800 rounded-xl divide-y divide-slate-100 dark:divide-slate-800">
                    {friends.map((f) => {
                      const checked = selectedFriendIds.includes(f.uid);
                      return (
                        <label
                          key={f.uid}
                          className="flex items-center justify-between px-3 py-2.5 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/60"
                        >
                          <div className="flex items-center gap-2.5">
                            <Avatar src={f.photoURL} name={f.displayName} size="sm" />
                            <span className="text-sm text-slate-900 dark:text-white">
                              {f.displayName}
                            </span>
                          </div>
                          <input
                            type="checkbox"
                            checked={checked}
                            onChange={() =>
                              setSelectedFriendIds((prev) =>
                                checked ? prev.filter((id) => id !== f.uid) : [...prev, f.uid]
                              )
                            }
                            className="w-4 h-4 accent-indigo-600"
                          />
                        </label>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            <div className="mt-6 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-sm font-medium text-slate-700 dark:text-slate-300"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={creating}
                className="px-5 py-2.5 rounded-xl fz-gradient text-white text-sm font-semibold hover:opacity-95 disabled:opacity-50"
              >
                {creating ? 'Creating...' : 'Create Group'}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
