import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  MessageSquarePlus,
  Search,
} from 'lucide-react';
import {
  collection,
  onSnapshot,
  orderBy,
  query,
} from 'firebase/firestore';
import { Avatar } from '../components/Avatar';
import { ChatThread } from '../components/ChatThread';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { formatRelativeTime } from '../lib/utils';
import {
  deleteDirectMessage,
  ensureDirectChat,
  markDirectChatRead,
  sendDirectMessage,
} from '../services/chatService';
import { ChatMessage, DirectChat, UserProfile } from '../types';

interface MyChatsPageProps {
  profile: UserProfile;
  friends: UserProfile[];
  directChats: DirectChat[];
  usersById: Record<string, UserProfile>;
  selectedChatId: string | null;
  onSelectChat: (chatId: string | null) => void;
  onBack?: () => void;
  maxFileSizeMB: number;
  isPlatformAdmin: boolean;
}

export const MyChatsPage: React.FC<MyChatsPageProps> = ({
  profile,
  friends,
  directChats,
  usersById,
  selectedChatId,
  onSelectChat,
  onBack,
  maxFileSizeMB,
  isPlatformAdmin,
}) => {
  const [search, setSearch] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [showNewChatPicker, setShowNewChatPicker] = useState(false);

  const activeChat = directChats.find((c) => c.id === selectedChatId) || null;
  const otherUid = activeChat
    ? activeChat.participantA === profile.uid
      ? activeChat.participantB
      : activeChat.participantA
    : null;
  const activePeer = otherUid ? usersById[otherUid] : undefined;

  useEffect(() => {
    if (!activeChat) {
      setMessages([]);
      return;
    }

    markDirectChatRead(activeChat, profile.uid).catch(() => {});

    const path = `directChats/${activeChat.id}/messages`;
    const q = query(collection(db, path), orderBy('createdAt', 'asc'));
    const unsub = onSnapshot(
      q,
      (snap) => {
        setMessages(snap.docs.map((d) => d.data() as ChatMessage));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, path)
    );

    return () => unsub();
  }, [activeChat?.id, profile.uid]);

  useEffect(() => {
    if (activeChat) {
      markDirectChatRead(activeChat, profile.uid).catch(() => {});
    }
  }, [messages.length]);

  const sortedChats = [...directChats].sort((a, b) => {
    const tA = a.lastMessageAt?.toMillis() || 0;
    const tB = b.lastMessageAt?.toMillis() || 0;
    return tB - tA;
  });

  const filteredChats = sortedChats.filter((chat) => {
    const peerUid = chat.participantA === profile.uid ? chat.participantB : chat.participantA;
    const peer = usersById[peerUid];
    const name = peer?.displayName || peerUid;
    return (
      !search.trim() ||
      name.toLowerCase().includes(search.toLowerCase()) ||
      chat.lastMessage.toLowerCase().includes(search.toLowerCase())
    );
  });

  const handleStartChatWithFriend = async (friendUid: string) => {
    const chatId = await ensureDirectChat(profile.uid, friendUid);
    setShowNewChatPicker(false);
    onSelectChat(chatId);
  };

  return (
    <div className="h-full flex overflow-hidden bg-white dark:bg-slate-900">
      {/* Left Conversation List */}
      <aside
        className={`${
          activeChat ? 'hidden md:flex' : 'flex'
        } w-full md:w-80 lg:w-96 flex-col border-r border-slate-200 dark:border-slate-800 shrink-0`}
      >
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              {onBack && (
                <button
                  type="button"
                  onClick={onBack}
                  className="w-9 h-9 -ml-1 rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0"
                  aria-label="Back"
                  title="Back"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
              )}
              <h1 className="font-display text-lg font-bold text-slate-900 dark:text-white truncate">
                My Chats
              </h1>
            </div>
            <button
              type="button"
              onClick={() => setShowNewChatPicker((v) => !v)}
              className="w-10 h-10 rounded-xl fz-gradient text-white flex items-center justify-center hover:opacity-95 transition-opacity shrink-0"
              title="Start new chat"
            >
              <MessageSquarePlus className="w-4 h-4" />
            </button>
          </div>

          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search conversations..."
              className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 pl-10 pr-3 py-2 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>

        {/* Friend Picker for Starting New Direct Chat */}
        {showNewChatPicker && (
          <div className="p-3 bg-indigo-50/70 dark:bg-indigo-950/30 border-b border-indigo-200 dark:border-indigo-900">
            <p className="text-xs font-semibold text-indigo-700 dark:text-indigo-300 mb-2">
              Start chat with a friend
            </p>
            {friends.length === 0 ? (
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Add friends first on the Add Friends page.
              </p>
            ) : (
              <div className="space-y-1 max-h-48 overflow-y-auto">
                {friends.map((f) => (
                  <button
                    key={f.uid}
                    type="button"
                    onClick={() => handleStartChatWithFriend(f.uid)}
                    className="w-full flex items-center gap-2.5 p-2 rounded-xl hover:bg-white dark:hover:bg-slate-800 text-left transition-colors"
                  >
                    <Avatar src={f.photoURL} name={f.displayName} size="sm" isOnline={f.isOnline} showPresence />
                    <span className="text-sm font-medium text-slate-900 dark:text-white truncate">
                      {f.displayName}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Conversations */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/70">
          {filteredChats.length === 0 ? (
            <div className="p-8 text-center">
              <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
                No chats yet
              </p>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Start a private conversation with any friend using the button above.
              </p>
            </div>
          ) : (
            filteredChats.map((chat) => {
              const peerUid = chat.participantA === profile.uid ? chat.participantB : chat.participantA;
              const peer = usersById[peerUid];
              const unread = chat.participantA === profile.uid ? chat.unreadA : chat.unreadB;
              const isSelected = chat.id === activeChat?.id;

              return (
                <button
                  key={chat.id}
                  type="button"
                  onClick={() => onSelectChat(chat.id)}
                  className={`w-full text-left px-4 py-3.5 flex items-center gap-3 transition-colors min-h-[68px] ${
                    isSelected
                      ? 'bg-indigo-50/90 dark:bg-indigo-950/40'
                      : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
                  }`}
                >
                  <Avatar
                    src={peer?.photoURL}
                    name={peer?.displayName || 'Friend'}
                    isOnline={peer?.isOnline}
                    showPresence
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                        {peer?.displayName || 'FRIENDZONE User'}
                      </p>
                      <span className="text-[11px] font-mono tabular-nums text-slate-400 shrink-0">
                        {formatRelativeTime(chat.lastMessageAt)}
                      </span>
                    </div>
                    <div className="mt-0.5 flex items-center justify-between gap-2">
                      <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                        {chat.lastMessage || 'No messages yet'}
                      </p>
                      {unread > 0 && (
                        <span className="min-w-[20px] h-5 px-1.5 rounded-full fz-gradient text-white text-[11px] font-mono tabular-nums font-semibold flex items-center justify-center shrink-0">
                          {unread}
                        </span>
                      )}
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </aside>

      {/* Right Active Thread */}
      <section className={`${activeChat ? 'flex' : 'hidden md:flex'} flex-1 flex-col min-w-0`}>
        {activeChat && otherUid ? (
          <>
            <header className="h-16 px-4 sm:px-6 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 bg-white dark:bg-slate-900 shrink-0">
              <div className="flex items-center gap-3 min-w-0">
                <button
                  type="button"
                  onClick={() => onSelectChat(null)}
                  className="w-10 h-10 -ml-2 rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                  aria-label="Back to chats"
                  title="Back to chats"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <Avatar
                  src={activePeer?.photoURL}
                  name={activePeer?.displayName || 'Friend'}
                  isOnline={activePeer?.isOnline}
                  showPresence
                />
                <div className="min-w-0">
                  <h2 className="font-display text-sm sm:text-base font-semibold text-slate-900 dark:text-white truncate">
                    {activePeer?.displayName || 'FRIENDZONE User'}
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                    {activePeer?.isOnline ? 'Online' : `Last seen ${formatRelativeTime(activePeer?.lastSeen)}`}
                    {activePeer?.uniqueCode ? ` · ${activePeer.uniqueCode}` : ''}
                  </p>
                </div>
              </div>
            </header>

            <div className="flex-1 min-h-0">
              <ChatThread
                messages={messages}
                currentUser={profile}
                canDeleteAny={isPlatformAdmin}
                storageFolder={`chats/${activeChat.id}`}
                maxFileSizeMB={maxFileSizeMB}
                reportContextPrefix={`directChats/${activeChat.id}/messages`}
                onSendMessage={async (payload) => {
                  await sendDirectMessage({
                    chat: activeChat,
                    sender: profile,
                    recipientUid: otherUid,
                    ...payload,
                  });
                }}
                onDeleteMessage={async (msgId) => {
                  await deleteDirectMessage(activeChat.id, msgId);
                }}
              />
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-slate-50/50 dark:bg-slate-950/40">
            <h2 className="font-display text-lg font-semibold text-slate-800 dark:text-slate-200">
              Select a conversation
            </h2>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400 max-w-sm">
              Choose a friend from the left panel or start a new one-to-one chat.
            </p>
          </div>
        )}
      </section>
    </div>
  );
};
