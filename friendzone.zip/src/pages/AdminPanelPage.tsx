import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Ban,
  CheckCircle2,
  Crown,
  Flag,
  MessageSquare,
  RefreshCw,
  Search,
  Settings,
  ShieldAlert,
  ShieldCheck,
  Trash2,
  Users,
  XCircle,
} from 'lucide-react';
import { Avatar } from '../components/Avatar';
import { useAuth } from '../contexts/AuthContext';
import { SUPER_ADMIN_UID, formatRelativeTime } from '../lib/utils';
import {
  addPlatformAdminRecord,
  deleteEntireGroup,
  fetchAllAdmins,
  fetchAllGroupsAdmin,
  fetchAllReportsAdmin,
  fetchAllUsersAdmin,
  fetchAdminStats,
  removePlatformAdminRecord,
  removeReportedContentAdmin,
  saveAppSettingsAdmin,
  toggleUserBlockedAdmin,
  updateReportStatusAdmin,
} from '../services/chatService';
import { AdminRecord, Group, ReportItem, UserProfile } from '../types';

interface AdminPanelPageProps {
  onBack?: () => void;
}

export const AdminPanelPage: React.FC<AdminPanelPageProps> = ({ onBack }) => {
  const { firebaseUser, profile, isAdmin, isSuperAdmin, appSettings, logout } = useAuth();

  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'groups' | 'reports' | 'settings'>('overview');
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalGroups: 0,
    totalMessages: 0,
    openReports: 0,
  });
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [reports, setReports] = useState<ReportItem[]>([]);
  const [admins, setAdmins] = useState<AdminRecord[]>([]);
  const [userSearch, setUserSearch] = useState('');
  const [feedback, setFeedback] = useState<string | null>(null);

  // Settings Form State
  const [allowRegistration, setAllowRegistration] = useState(appSettings.allowRegistration);
  const [allowGroupCreation, setAllowGroupCreation] = useState(appSettings.allowGroupCreation);
  const [maxGroupSize, setMaxGroupSize] = useState(appSettings.maxGroupSize);
  const [maxFileSizeMB, setMaxFileSizeMB] = useState(appSettings.maxFileSizeMB);
  const [maintenanceMode, setMaintenanceMode] = useState(appSettings.maintenanceMode);
  const [announcementBanner, setAnnouncementBanner] = useState(appSettings.announcementBanner);

  useEffect(() => {
    setAllowRegistration(appSettings.allowRegistration);
    setAllowGroupCreation(appSettings.allowGroupCreation);
    setMaxGroupSize(appSettings.maxGroupSize);
    setMaxFileSizeMB(appSettings.maxFileSizeMB);
    setMaintenanceMode(appSettings.maintenanceMode);
    setAnnouncementBanner(appSettings.announcementBanner);
  }, [appSettings]);

  const loadDashboard = async () => {
    if (!isAdmin) return;
    setLoading(true);
    try {
      const [s, u, g, r, a] = await Promise.all([
        fetchAdminStats(),
        fetchAllUsersAdmin(),
        fetchAllGroupsAdmin(),
        fetchAllReportsAdmin(),
        fetchAllAdmins(),
      ]);
      setStats(s);
      setUsers(u);
      setGroups(g);
      setReports(r);
      setAdmins(a);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAdmin) {
      loadDashboard();
    }
  }, [isAdmin]);

  if (!isAdmin) {
    return (
      <div className="h-full overflow-y-auto p-6 flex items-center justify-center">
        <div className="max-w-md w-full rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-8 text-center">
          <div className="w-12 h-12 rounded-2xl fz-gradient text-white flex items-center justify-center mx-auto">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <h1 className="mt-4 font-display text-xl font-bold text-slate-900 dark:text-white">
            Administrator Access Required
          </h1>
          <p className="mt-2 text-sm text-slate-500 dark:text-slate-400 leading-relaxed">
            Your current account (<span className="font-mono text-xs">{firebaseUser?.email || profile?.uid}</span>) does not have administrator privileges. Sign out and sign in with an authorized administrator account to access the Admin Dashboard.
          </p>
          <div className="mt-6 flex flex-col gap-2">
            <button
              type="button"
              onClick={logout}
              className="w-full rounded-xl fz-gradient py-2.5 px-4 text-sm font-semibold text-white hover:opacity-95"
            >
              Sign Out to Switch Account
            </button>
            {onBack && (
              <button
                type="button"
                onClick={onBack}
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 py-2.5 px-4 text-sm font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 inline-flex items-center justify-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back</span>
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  const notify = (msg: string) => {
    setFeedback(msg);
    setTimeout(() => setFeedback(null), 3500);
  };

  const filteredUsers = users.filter((u) => {
    const q = userSearch.trim().toLowerCase();
    return (
      !q ||
      u.displayName.toLowerCase().includes(q) ||
      u.uniqueCode.toLowerCase().includes(q) ||
      u.uid.toLowerCase().includes(q)
    );
  });

  const isTargetPlatformAdmin = (uid: string) =>
    uid === SUPER_ADMIN_UID || admins.some((a) => a.uid === uid);

  const handleToggleBlock = async (u: UserProfile) => {
    if (u.uid === SUPER_ADMIN_UID) return;
    const next = !u.isBlocked;
    await toggleUserBlockedAdmin(u.uid, next);
    setUsers((prev) => prev.map((item) => (item.uid === u.uid ? { ...item, isBlocked: next } : item)));
    notify(`${u.displayName} has been ${next ? 'blocked' : 'unblocked'}.`);
  };

  const handleTogglePlatformAdmin = async (u: UserProfile) => {
    if (!firebaseUser || u.uid === SUPER_ADMIN_UID) return;
    if (isTargetPlatformAdmin(u.uid)) {
      await removePlatformAdminRecord(u.uid);
      setAdmins((prev) => prev.filter((a) => a.uid !== u.uid));
      notify(`Removed admin role from ${u.displayName}.`);
    } else {
      await addPlatformAdminRecord(firebaseUser.uid, u.uid, '');
      setAdmins((prev) => [
        ...prev,
        { uid: u.uid, email: '', role: 'admin', addedBy: firebaseUser.uid, createdAt: null },
      ]);
      notify(`Granted admin role to ${u.displayName}.`);
    }
  };

  const handleDeleteGroup = async (grp: Group) => {
    await deleteEntireGroup(grp.id);
    setGroups((prev) => prev.filter((g) => g.id !== grp.id));
    setStats((s) => ({ ...s, totalGroups: Math.max(0, s.totalGroups - 1) }));
    notify(`Deleted group "${grp.name}".`);
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!firebaseUser) return;
    await saveAppSettingsAdmin(firebaseUser.uid, {
      allowRegistration,
      allowGroupCreation,
      maxGroupSize,
      maxFileSizeMB,
      maintenanceMode,
      announcementBanner,
    });
    notify('Application settings saved.');
  };

  return (
    <div className="h-full overflow-y-auto p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Top Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            {onBack && (
              <button
                type="button"
                onClick={onBack}
                className="mt-0.5 w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0"
                aria-label="Back"
                title="Back"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            )}
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold text-indigo-600 dark:text-indigo-400">
                <ShieldCheck className="w-4 h-4" />
                <span>{isSuperAdmin ? 'Super Administrator' : 'Administrator'} Console</span>
              </div>
              <h1 className="mt-1 font-display text-2xl font-bold text-slate-900 dark:text-white">
                FRIENDZONE Admin Dashboard
              </h1>
            </div>
          </div>

          <button
            type="button"
            onClick={loadDashboard}
            disabled={loading}
            className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 inline-flex items-center gap-2 min-h-[40px] self-start sm:self-auto"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh Data</span>
          </button>
        </div>

        {feedback && (
          <div className="rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 px-4 py-3 text-xs text-emerald-700 dark:text-emerald-300">
            {feedback}
          </div>
        )}

        {/* Segmented Tab Controls */}
        <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-x-auto">
          {(
            [
              { id: 'overview', label: 'Overview' },
              { id: 'users', label: `Users (${users.length})` },
              { id: 'groups', label: `Groups (${groups.length})` },
              { id: 'reports', label: `Reports (${reports.filter((r) => r.status === 'open').length})` },
              { id: 'settings', label: 'App Settings' },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
                activeTab === tab.id
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* OVERVIEW TAB */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5">
                <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
                  <span className="text-xs font-medium">Total Registered Users</span>
                  <Users className="w-4 h-4 text-blue-600" />
                </div>
                <p className="mt-3 font-display text-3xl font-bold tabular-nums text-slate-900 dark:text-white">
                  {stats.totalUsers}
                </p>
              </div>

              <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5">
                <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
                  <span className="text-xs font-medium">Total Groups</span>
                  <Crown className="w-4 h-4 text-purple-600" />
                </div>
                <p className="mt-3 font-display text-3xl font-bold tabular-nums text-slate-900 dark:text-white">
                  {stats.totalGroups}
                </p>
              </div>

              <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5">
                <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
                  <span className="text-xs font-medium">Total Messages</span>
                  <MessageSquare className="w-4 h-4 text-indigo-600" />
                </div>
                <p className="mt-3 font-display text-3xl font-bold tabular-nums text-slate-900 dark:text-white">
                  {stats.totalMessages}
                </p>
              </div>

              <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5">
                <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
                  <span className="text-xs font-medium">Open Reports</span>
                  <Flag className="w-4 h-4 text-amber-600" />
                </div>
                <p className="mt-3 font-display text-3xl font-bold tabular-nums text-slate-900 dark:text-white">
                  {stats.openReports}
                </p>
              </div>
            </div>

            <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6">
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                Recent Registrations
              </h2>
              <div className="mt-4 divide-y divide-slate-100 dark:divide-slate-800">
                {users.slice(0, 6).map((u) => (
                  <div key={u.uid} className="py-3 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <Avatar src={u.photoURL} name={u.displayName} isOnline={u.isOnline} showPresence />
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-slate-900 dark:text-white truncate">
                          {u.displayName}
                        </p>
                        <p className="text-xs text-slate-500 dark:text-slate-400 font-mono truncate">
                          {u.uniqueCode} · {u.uid}
                        </p>
                      </div>
                    </div>
                    <span className="text-xs text-slate-400 font-mono tabular-nums shrink-0">
                      {u.isBlocked ? 'Blocked' : 'Active'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* USERS TAB */}
        {activeTab === 'users' && (
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                All Users
              </h2>
              <div className="relative w-full sm:w-72">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  placeholder="Search name, ID, or UID..."
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 pl-10 pr-3 py-2 text-sm text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
                    <th className="py-3 px-4 font-medium">User</th>
                    <th className="py-3 px-4 font-medium">Unique ID</th>
                    <th className="py-3 px-4 font-medium">Status</th>
                    <th className="py-3 px-4 font-medium">Role</th>
                    <th className="py-3 px-4 font-medium text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                  {filteredUsers.map((u) => {
                    const isUserAdmin = isTargetPlatformAdmin(u.uid);
                    return (
                      <tr key={u.uid} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3">
                            <Avatar src={u.photoURL} name={u.displayName} size="sm" isOnline={u.isOnline} showPresence />
                            <div>
                              <p className="font-medium text-slate-900 dark:text-white">{u.displayName}</p>
                              <p className="text-xs text-slate-400 font-mono">{u.uid.slice(0, 14)}...</p>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-4 font-mono text-xs text-slate-600 dark:text-slate-300">
                          {u.uniqueCode}
                        </td>
                        <td className="py-3 px-4 text-xs">
                          <span className={u.isBlocked ? 'text-rose-600 dark:text-rose-400 font-medium' : 'text-emerald-600 dark:text-emerald-400 font-medium'}>
                            {u.isBlocked ? 'Blocked' : 'Active'}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-xs text-slate-600 dark:text-slate-300">
                          {u.uid === SUPER_ADMIN_UID ? 'Super Admin' : isUserAdmin ? 'Admin' : 'Member'}
                        </td>
                        <td className="py-3 px-4 text-right space-x-2 whitespace-nowrap">
                          {u.uid !== SUPER_ADMIN_UID && (
                            <>
                              {isSuperAdmin && (
                                <button
                                  type="button"
                                  onClick={() => handleTogglePlatformAdmin(u)}
                                  className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                                >
                                  {isUserAdmin ? 'Revoke Admin' : 'Make Admin'}
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => handleToggleBlock(u)}
                                className={`px-3 py-1.5 rounded-lg text-xs font-medium inline-flex items-center gap-1 ${
                                  u.isBlocked
                                    ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300'
                                    : 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300'
                                }`}
                              >
                                <Ban className="w-3.5 h-3.5" />
                                <span>{u.isBlocked ? 'Unblock' : 'Block'}</span>
                              </button>
                            </>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* GROUPS TAB */}
        {activeTab === 'groups' && (
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800">
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                Group Moderation
              </h2>
            </div>

            {groups.length === 0 ? (
              <p className="p-8 text-sm text-slate-500 dark:text-slate-400 text-center">
                No groups exist yet.
              </p>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {groups.map((grp) => (
                  <div key={grp.id} className="p-4 sm:px-6 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3 min-w-0">
                      <Avatar src={grp.photoURL} name={grp.name} isGroup />
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                          {grp.name}
                        </p>
                        <p className="text-xs text-slate-500 dark:text-slate-400 truncate tabular-nums">
                          {grp.memberCount} members · Created {formatRelativeTime(grp.createdAt)} · {grp.description || 'No description'}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleDeleteGroup(grp)}
                      className="px-3.5 py-2 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 text-xs font-medium hover:bg-rose-100 dark:hover:bg-rose-900/50 inline-flex items-center gap-1.5 shrink-0"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete Group</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* REPORTS TAB */}
        {activeTab === 'reports' && (
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800">
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                Content & User Reports
              </h2>
            </div>

            {reports.length === 0 ? (
              <p className="p-8 text-sm text-slate-500 dark:text-slate-400 text-center">
                No moderation reports submitted.
              </p>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {reports.map((rep) => (
                  <div key={rep.id} className="p-4 sm:px-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="space-y-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 text-xs">
                        <span className="font-semibold text-slate-900 dark:text-white">
                          {rep.targetLabel}
                        </span>
                        <span className="text-slate-400">·</span>
                        <span className="text-slate-500 dark:text-slate-400 capitalize">
                          {rep.targetType}
                        </span>
                        <span className="text-slate-400">·</span>
                        <span
                          className={`font-medium capitalize ${
                            rep.status === 'open'
                              ? 'text-amber-600 dark:text-amber-400'
                              : rep.status === 'resolved'
                                ? 'text-emerald-600 dark:text-emerald-400'
                                : 'text-slate-400'
                          }`}
                        >
                          {rep.status}
                        </span>
                      </div>
                      <p className="text-sm text-slate-700 dark:text-slate-200">{rep.reason}</p>
                      <p className="text-xs text-slate-400">
                        Reported by {rep.reporterName} · {formatRelativeTime(rep.createdAt)}
                      </p>
                    </div>

                    {rep.status === 'open' && (
                      <div className="flex flex-wrap items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={async () => {
                            await removeReportedContentAdmin(rep);
                            setReports((prev) =>
                              prev.map((r) => (r.id === rep.id ? { ...r, status: 'resolved' } : r))
                            );
                            notify('Content removed and report resolved.');
                          }}
                          className="px-3 py-1.5 rounded-lg bg-rose-600 text-white text-xs font-medium hover:bg-rose-700 inline-flex items-center gap-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Remove Content</span>
                        </button>
                        <button
                          type="button"
                          onClick={async () => {
                            await updateReportStatusAdmin(rep.id, 'resolved');
                            setReports((prev) =>
                              prev.map((r) => (r.id === rep.id ? { ...r, status: 'resolved' } : r))
                            );
                          }}
                          className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-emerald-600 dark:text-emerald-400 inline-flex items-center gap-1"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Resolve</span>
                        </button>
                        <button
                          type="button"
                          onClick={async () => {
                            await updateReportStatusAdmin(rep.id, 'dismissed');
                            setReports((prev) =>
                              prev.map((r) => (r.id === rep.id ? { ...r, status: 'dismissed' } : r))
                            );
                          }}
                          className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-500 inline-flex items-center gap-1"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          <span>Dismiss</span>
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* APP SETTINGS TAB */}
        {activeTab === 'settings' && (
          <form
            onSubmit={handleSaveSettings}
            className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 space-y-5 max-w-2xl"
          >
            <div className="flex items-center gap-2">
              <Settings className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                Global Application Controls
              </h2>
            </div>

            <label className="flex items-center justify-between gap-4 py-2">
              <div>
                <p className="text-sm font-medium text-slate-900 dark:text-white">Allow New Registrations</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Enable or pause new sign-ups.</p>
              </div>
              <input
                type="checkbox"
                checked={allowRegistration}
                onChange={(e) => setAllowRegistration(e.target.checked)}
                className="w-5 h-5 accent-indigo-600"
              />
            </label>

            <label className="flex items-center justify-between gap-4 py-2">
              <div>
                <p className="text-sm font-medium text-slate-900 dark:text-white">Allow Group Creation</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Let members create new group chats.</p>
              </div>
              <input
                type="checkbox"
                checked={allowGroupCreation}
                onChange={(e) => setAllowGroupCreation(e.target.checked)}
                className="w-5 h-5 accent-indigo-600"
              />
            </label>

            <label className="flex items-center justify-between gap-4 py-2">
              <div>
                <p className="text-sm font-medium text-slate-900 dark:text-white">Maintenance Mode</p>
                <p className="text-xs text-slate-500 dark:text-slate-400">Display maintenance notice to non-admin users.</p>
              </div>
              <input
                type="checkbox"
                checked={maintenanceMode}
                onChange={(e) => setMaintenanceMode(e.target.checked)}
                className="w-5 h-5 accent-indigo-600"
              />
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Max Group Members
                </label>
                <input
                  type="number"
                  min={2}
                  max={5000}
                  value={maxGroupSize}
                  onChange={(e) => setMaxGroupSize(Number(e.target.value))}
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3.5 py-2 text-sm font-mono tabular-nums text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Max File Upload (MB)
                </label>
                <input
                  type="number"
                  min={1}
                  max={50}
                  value={maxFileSizeMB}
                  onChange={(e) => setMaxFileSizeMB(Number(e.target.value))}
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3.5 py-2 text-sm font-mono tabular-nums text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Global Announcement Banner (optional)
              </label>
              <input
                type="text"
                maxLength={300}
                value={announcementBanner}
                onChange={(e) => setAnnouncementBanner(e.target.value)}
                placeholder="Broadcast a message across all active FRIENDZONE screens..."
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-4 py-2.5 text-sm text-slate-900 dark:text-white"
              />
            </div>

            <button
              type="submit"
              className="rounded-xl fz-gradient px-5 py-2.5 text-sm font-semibold text-white hover:opacity-95"
            >
              Save Settings
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
