import React, { useState } from 'react';
import {
  ArrowLeft,
  Bell,
  BellRing,
  Check,
  CheckCheck,
  MessageCircle,
  Trash2,
  UserPlus,
  Users,
} from 'lucide-react';
import { requestPushMessagingToken } from '../lib/firebase';
import { formatRelativeTime } from '../lib/utils';
import {
  deleteNotification,
  markAllNotificationsRead,
  markNotificationRead,
} from '../services/chatService';
import { NotificationItem, PageRoute, UserPrivate } from '../types';

interface NotificationsPageProps {
  notifications: NotificationItem[];
  privateData: UserPrivate | null;
  onUpdatePrivatePrefs: (updates: Partial<Pick<UserPrivate, 'notificationsEnabled' | 'fcmToken'>>) => Promise<void>;
  onNavigate: (page: PageRoute) => void;
  onOpenChat: (chatId: string) => void;
  onOpenGroup: (groupId: string) => void;
  onBack?: () => void;
}

export const NotificationsPage: React.FC<NotificationsPageProps> = ({
  notifications,
  privateData,
  onUpdatePrivatePrefs,
  onNavigate,
  onOpenChat,
  onOpenGroup,
  onBack,
}) => {
  const [pushFeedback, setPushFeedback] = useState<string | null>(null);
  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleEnableBrowserPush = async () => {
    setPushFeedback(null);
    if (typeof Notification === 'undefined') {
      setPushFeedback('Desktop notifications are not supported in this browser.');
      return;
    }
    const perm = await Notification.requestPermission();
    if (perm !== 'granted') {
      setPushFeedback('Notification permission was denied in browser settings.');
      return;
    }
    await onUpdatePrivatePrefs({ notificationsEnabled: true });
    const vapid = import.meta.env.VITE_FIREBASE_VAPID_KEY as string | undefined;
    const token = await requestPushMessagingToken(vapid);
    if (token) {
      await onUpdatePrivatePrefs({ fcmToken: token, notificationsEnabled: true });
      setPushFeedback('Push notifications and FCM device token active.');
    } else {
      setPushFeedback('Browser alerts enabled. Add VITE_FIREBASE_VAPID_KEY for background FCM push.');
    }
  };

  const handleOpenNotification = async (item: NotificationItem) => {
    if (!item.read) {
      await markNotificationRead(item.id);
    }
    if (item.targetType === 'chat' && item.targetId) {
      onOpenChat(item.targetId);
    } else if (item.targetType === 'group' && item.targetId) {
      onOpenGroup(item.targetId);
    } else if (item.targetType === 'friends') {
      onNavigate('friends');
    }
  };

  const renderIcon = (type: NotificationItem['type']) => {
    if (type === 'friend_request' || type === 'friend_accepted') {
      return <UserPlus className="w-4 h-4 text-blue-600 dark:text-blue-400" />;
    }
    if (type === 'group_invite' || type === 'group_message') {
      return <Users className="w-4 h-4 text-purple-600 dark:text-purple-400" />;
    }
    if (type === 'direct_message') {
      return <MessageCircle className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />;
    }
    return <Bell className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />;
  };

  return (
    <div className="h-full overflow-y-auto p-4 sm:p-6 lg:p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            {onBack && (
              <button
                type="button"
                onClick={onBack}
                className="mt-0.5 w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0"
                aria-label="Back"
                title="Back"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            )}
            <div>
              <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
                Notifications
              </h1>
              <p className="mt-1 text-sm text-slate-500 dark:text-slate-400 tabular-nums">
                {unreadCount} unread · {notifications.length} total alerts
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={handleEnableBrowserPush}
              className="px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 inline-flex items-center gap-2 min-h-[40px]"
            >
              <BellRing className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span>
                {privateData?.notificationsEnabled ? 'Push Alerts On' : 'Enable Push Alerts'}
              </span>
            </button>

            {unreadCount > 0 && (
              <button
                type="button"
                onClick={() => markAllNotificationsRead(notifications)}
                className="px-3.5 py-2 rounded-xl fz-gradient text-white text-xs font-semibold hover:opacity-95 inline-flex items-center gap-2 min-h-[40px]"
              >
                <CheckCheck className="w-4 h-4" />
                <span>Mark All Read</span>
              </button>
            )}
          </div>
        </div>

        {pushFeedback && (
          <div className="rounded-xl bg-indigo-50 dark:bg-indigo-950/50 border border-indigo-200 dark:border-indigo-900 px-4 py-3 text-xs text-indigo-800 dark:text-indigo-300">
            {pushFeedback}
          </div>
        )}

        <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800">
          {notifications.length === 0 ? (
            <div className="p-12 text-center">
              <Bell className="w-9 h-9 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
              <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
                All caught up
              </p>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Friend requests, group invites, and message alerts will appear here in real time.
              </p>
            </div>
          ) : (
            notifications.map((item) => (
              <div
                key={item.id}
                className={`p-4 sm:px-6 flex items-start justify-between gap-4 transition-colors ${
                  item.read ? '' : 'bg-indigo-50/40 dark:bg-indigo-950/20'
                }`}
              >
                <button
                  type="button"
                  onClick={() => handleOpenNotification(item)}
                  className="flex items-start gap-3.5 text-left flex-1 min-w-0"
                >
                  <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center shrink-0 mt-0.5">
                    {renderIcon(item.type)}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                        {item.title}
                      </p>
                      {!item.read && (
                        <span className="w-2 h-2 rounded-full fz-gradient shrink-0" />
                      )}
                    </div>
                    <p className="mt-0.5 text-sm text-slate-600 dark:text-slate-300 line-clamp-2">
                      {item.body}
                    </p>
                    <p className="mt-1 text-xs text-slate-400 font-mono tabular-nums">
                      {item.senderName} · {formatRelativeTime(item.createdAt)}
                    </p>
                  </div>
                </button>

                <div className="flex items-center gap-1 shrink-0">
                  {!item.read && (
                    <button
                      type="button"
                      onClick={() => markNotificationRead(item.id)}
                      className="p-2 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800"
                      title="Mark as read"
                    >
                      <Check className="w-4 h-4" />
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => deleteNotification(item.id)}
                    className="p-2 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800"
                    title="Delete"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </section>
      </div>
    </div>
  );
};
