import React, { useState } from 'react';
import {
  ArrowRight,
  Bell,
  Copy,
  Check,
  MessageCircle,
  Sparkles,
  UserPlus,
  Users,
} from 'lucide-react';
import { Avatar } from '../components/Avatar';
import { formatRelativeTime } from '../lib/utils';
import { seedDemoWorkspace } from '../services/chatService';
import {
  DirectChat,
  NotificationItem,
  PageRoute,
  UserGroupSummary,
  UserProfile,
} from '../types';

interface HomePageProps {
  profile: UserProfile;
  friends: UserProfile[];
  directChats: DirectChat[];
  groups: UserGroupSummary[];
  notifications: NotificationItem[];
  onNavigate: (page: PageRoute) => void;
  onOpenChat: (chatId: string) => void;
  onOpenGroup: (groupId: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  profile,
  friends,
  directChats,
  groups,
  notifications,
  onNavigate,
  onOpenChat,
  onOpenGroup,
}) => {
  const [seeding, setSeeding] = useState(false);
  const [copiedId, setCopiedId] = useState(false);
  const [seedMessage, setSeedMessage] = useState<string | null>(null);

  const unreadChatsCount = directChats.reduce((acc, chat) => {
    const isA = chat.participantA === profile.uid;
    return acc + (isA ? chat.unreadA : chat.unreadB);
  }, 0);
  const unreadNotifsCount = notifications.filter((n) => !n.read).length;

  const handleCopyCode = async () => {
    try {
      await navigator.clipboard.writeText(profile.uniqueCode);
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    } catch {
      // Clipboard blocked
    }
  };

  const handleSeedDemo = async () => {
    setSeeding(true);
    setSeedMessage(null);
    try {
      await seedDemoWorkspace(profile);
      setSeedMessage('Sample friends, Weekend Creators group, and chats added to Firestore.');
    } catch (err) {
      setSeedMessage(err instanceof Error ? err.message : 'Unable to load sample data.');
    } finally {
      setSeeding(false);
    }
  };

  return (
    <div className="h-full overflow-y-auto p-4 sm:p-6 lg:p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Hero Welcome Banner */}
        <section className="rounded-3xl fz-gradient text-white p-6 sm:p-8 shadow-sm">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div>
              <p className="text-xs font-medium text-white/80">
                Welcome back to FRIENDZONE
              </p>
              <h1 className="mt-1 font-display text-2xl sm:text-3xl font-bold tracking-tight [text-wrap:balance]">
                Hello, {profile.displayName}
              </h1>
              <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-white/85">
                <span>Your Unique User ID:</span>
                <button
                  type="button"
                  onClick={handleCopyCode}
                  className="inline-flex items-center gap-1.5 font-mono font-semibold bg-white/15 hover:bg-white/25 px-2.5 py-1 rounded-lg transition-colors"
                >
                  <span>{profile.uniqueCode}</span>
                  {copiedId ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                onClick={() => onNavigate('friends')}
                className="rounded-xl bg-white text-indigo-700 px-4 py-2.5 text-sm font-semibold hover:bg-white/95 transition-colors inline-flex items-center gap-2 min-h-[44px]"
              >
                <UserPlus className="w-4 h-4" />
                <span>Add Friends</span>
              </button>
              <button
                type="button"
                onClick={() => onNavigate('groups')}
                className="rounded-xl bg-white/15 hover:bg-white/25 text-white px-4 py-2.5 text-sm font-medium transition-colors inline-flex items-center gap-2 min-h-[44px]"
              >
                <Users className="w-4 h-4" />
                <span>New Group</span>
              </button>
            </div>
          </div>
        </section>

        {/* Demo Workspace Prompt if New User */}
        {friends.length === 0 && groups.length === 0 && (
          <section className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                Explore with sample friends & group chats
              </h2>
              <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
                Populate real Firestore contacts (Maya Lin & Marcus Vance), a group chat, and sample messages to test replies, media, and notifications.
              </p>
              {seedMessage && (
                <p className="mt-2 text-xs font-medium text-indigo-600 dark:text-indigo-400">
                  {seedMessage}
                </p>
              )}
            </div>
            <button
              type="button"
              disabled={seeding}
              onClick={handleSeedDemo}
              className="shrink-0 rounded-xl fz-gradient px-4 py-2.5 text-sm font-semibold text-white hover:opacity-95 disabled:opacity-50 inline-flex items-center gap-2 min-h-[44px]"
            >
              <Sparkles className="w-4 h-4" />
              <span>{seeding ? 'Loading Demo...' : 'Load Sample Workspace'}</span>
            </button>
          </section>
        )}

        {/* 4-Column Stats Row */}
        <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <button
            type="button"
            onClick={() => onNavigate('chats')}
            className="text-left rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 hover:border-indigo-300 dark:hover:border-indigo-700 transition-colors"
          >
            <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
              <span className="text-xs font-medium">Direct Chats</span>
              <MessageCircle className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            </div>
            <p className="mt-3 font-display text-2xl font-bold tabular-nums text-slate-900 dark:text-white">
              {directChats.length}
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 tabular-nums">
              {unreadChatsCount} unread
            </p>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('groups')}
            className="text-left rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 hover:border-indigo-300 dark:hover:border-indigo-700 transition-colors"
          >
            <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
              <span className="text-xs font-medium">Groups</span>
              <Users className="w-4 h-4 text-purple-600 dark:text-purple-400" />
            </div>
            <p className="mt-3 font-display text-2xl font-bold tabular-nums text-slate-900 dark:text-white">
              {groups.length}
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Active memberships
            </p>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('friends')}
            className="text-left rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 hover:border-indigo-300 dark:hover:border-indigo-700 transition-colors"
          >
            <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
              <span className="text-xs font-medium">Friends</span>
              <UserPlus className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            </div>
            <p className="mt-3 font-display text-2xl font-bold tabular-nums text-slate-900 dark:text-white">
              {friends.length}
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 tabular-nums">
              {friends.filter((f) => f.isOnline).length} online now
            </p>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('notifications')}
            className="text-left rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 hover:border-indigo-300 dark:hover:border-indigo-700 transition-colors"
          >
            <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
              <span className="text-xs font-medium">Notifications</span>
              <Bell className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            </div>
            <p className="mt-3 font-display text-2xl font-bold tabular-nums text-slate-900 dark:text-white">
              {unreadNotifsCount}
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 tabular-nums">
              {notifications.length} total alerts
            </p>
          </button>
        </section>

        {/* Two Column Content: Friends & Recent Groups */}
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Active Friends */}
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                Friends
              </h2>
              <button
                type="button"
                onClick={() => onNavigate('friends')}
                className="text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1"
              >
                <span>Manage</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {friends.length === 0 ? (
              <p className="mt-6 text-sm text-slate-500 dark:text-slate-400">
                No friends connected yet. Share your ID <span className="font-mono">{profile.uniqueCode}</span> or search in Add Friends.
              </p>
            ) : (
              <div className="mt-4 divide-y divide-slate-100 dark:divide-slate-800">
                {friends.slice(0, 5).map((friend) => (
                  <div key={friend.uid} className="py-3 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <Avatar
                        src={friend.photoURL}
                        name={friend.displayName}
                        isOnline={friend.isOnline}
                        showPresence
                      />
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-slate-900 dark:text-white truncate">
                          {friend.displayName}
                        </p>
                        <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                          {friend.isOnline ? 'Online' : 'Offline'} · <span className="font-mono">{friend.uniqueCode}</span>
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => onOpenChat([profile.uid, friend.uid].sort().join('_'))}
                      className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 shrink-0 min-h-[36px]"
                    >
                      Message
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Your Groups */}
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                Your Groups
              </h2>
              <button
                type="button"
                onClick={() => onNavigate('groups')}
                className="text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1"
              >
                <span>Open Groups</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {groups.length === 0 ? (
              <p className="mt-6 text-sm text-slate-500 dark:text-slate-400">
                You have not joined any groups yet. Create a new group room to collaborate with friends.
              </p>
            ) : (
              <div className="mt-4 divide-y divide-slate-100 dark:divide-slate-800">
                {groups.slice(0, 5).map((grp) => (
                  <button
                    key={grp.groupId}
                    type="button"
                    onClick={() => onOpenGroup(grp.groupId)}
                    className="w-full text-left py-3 flex items-center justify-between gap-3 hover:bg-slate-50 dark:hover:bg-slate-800/50 -mx-2 px-2 rounded-xl transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <Avatar src={grp.photoURL} name={grp.name} isGroup />
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-slate-900 dark:text-white truncate">
                          {grp.name}
                        </p>
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          {grp.role === 'admin' ? 'Group Admin' : 'Member'} · Joined {formatRelativeTime(grp.joinedAt)}
                        </p>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-400 shrink-0" />
                  </button>
                ))}
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
};
