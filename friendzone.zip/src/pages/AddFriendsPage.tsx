import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Check,
  Copy,
  MessageCircle,
  Phone,
  Search,
  Trash2,
  User as UserIcon,
  UserCheck,
  UserMinus,
  UserPlus,
  X,
} from 'lucide-react';
import { Avatar } from '../components/Avatar';
import {
  addFriendByNameAndNumber,
  deleteSavedContact,
  ensureDirectChat,
  lookupUserByUniqueCode,
  removeFriendship,
  respondFriendRequest,
  searchActiveUsers,
  sendFriendRequest,
} from '../services/chatService';
import { Friendship, SavedContact, UserProfile } from '../types';

interface AddFriendsPageProps {
  profile: UserProfile;
  friendships: Friendship[];
  friends: UserProfile[];
  savedContacts: SavedContact[];
  usersById: Record<string, UserProfile>;
  onOpenChat: (chatId: string) => void;
  onBack?: () => void;
}

export const AddFriendsPage: React.FC<AddFriendsPageProps> = ({
  profile,
  friendships,
  friends,
  savedContacts,
  usersById,
  onOpenChat,
  onBack,
}) => {
  // Add Friend by Name & Number state
  const [friendName, setFriendName] = useState('');
  const [friendPhone, setFriendPhone] = useState('');
  const [addingByPhone, setAddingByPhone] = useState(false);
  const [phoneResultMsg, setPhoneResultMsg] = useState<string | null>(null);
  const [phoneErrorMsg, setPhoneErrorMsg] = useState<string | null>(null);
  const [nameCandidates, setNameCandidates] = useState<UserProfile[]>([]);

  // Lookup by Unique ID state
  const [codeInput, setCodeInput] = useState('');
  const [codeResult, setCodeResult] = useState<UserProfile | null>(null);
  const [codeError, setCodeError] = useState<string | null>(null);

  // Directory Search
  const [searchTerm, setSearchTerm] = useState('');
  const [directoryUsers, setDirectoryUsers] = useState<UserProfile[]>([]);
  const [loadingSearch, setLoadingSearch] = useState(false);
  const [copied, setCopied] = useState(false);
  const [actionBanner, setActionBanner] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    const load = async () => {
      setLoadingSearch(true);
      try {
        const list = await searchActiveUsers(searchTerm, profile.uid);
        if (active) setDirectoryUsers(list);
      } finally {
        if (active) setLoadingSearch(false);
      }
    };
    const timer = setTimeout(load, 200);
    return () => {
      active = false;
      clearTimeout(timer);
    };
  }, [searchTerm, profile.uid]);

  const incomingRequests = friendships.filter(
    (f) => f.status === 'pending' && f.recipientId === profile.uid
  );
  const outgoingRequests = friendships.filter(
    (f) => f.status === 'pending' && f.requesterId === profile.uid
  );

  const getFriendshipWith = (uid: string): Friendship | undefined =>
    friendships.find((f) => f.users.includes(uid));

  const handleCopyMyCode = async () => {
    try {
      await navigator.clipboard.writeText(profile.uniqueCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Ignore clipboard failures
    }
  };

  const handleAddByNameAndPhone = async (e: React.FormEvent) => {
    e.preventDefault();
    setPhoneErrorMsg(null);
    setPhoneResultMsg(null);
    setNameCandidates([]);
    setAddingByPhone(true);
    try {
      const res = await addFriendByNameAndNumber(profile, friendName, friendPhone);
      if (res.outcome === 'request_sent' && res.matchedUser) {
        setPhoneResultMsg(
          `Found ${res.matchedUser.displayName}! Friend request sent and contact saved.`
        );
        setFriendName('');
        setFriendPhone('');
      } else if (res.outcome === 'already_friends' && res.matchedUser) {
        setPhoneResultMsg(`You and ${res.matchedUser.displayName} are already friends.`);
      } else if (res.outcome === 'already_pending' && res.matchedUser) {
        setPhoneResultMsg(`Friend request to ${res.matchedUser.displayName} is already pending.`);
      } else {
        setPhoneResultMsg(
          `Saved "${friendName}" (${friendPhone}) to your contacts. No user has linked that number yet—invite them with your ID ${profile.uniqueCode} or connect with a matching profile below.`
        );
        setNameCandidates(res.nameCandidates);
        setFriendName('');
        setFriendPhone('');
      }
    } catch (err) {
      setPhoneErrorMsg(err instanceof Error ? err.message : 'Unable to add friend.');
    } finally {
      setAddingByPhone(false);
    }
  };

  const handleLookupCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setCodeError(null);
    setCodeResult(null);
    const user = await lookupUserByUniqueCode(codeInput);
    if (!user) {
      setCodeError('No FRIENDZONE user matched that Unique ID.');
      return;
    }
    if (user.uid === profile.uid) {
      setCodeError('That is your own Unique User ID.');
      return;
    }
    setCodeResult(user);
  };

  const handleSendRequest = async (target: UserProfile) => {
    setActionBanner(null);
    try {
      await sendFriendRequest(profile, target);
      setActionBanner(`Friend request sent to ${target.displayName}.`);
    } catch (err) {
      setActionBanner(err instanceof Error ? err.message : 'Unable to send friend request.');
    }
  };

  const handleStartChat = async (friendUid: string) => {
    const chatId = await ensureDirectChat(profile.uid, friendUid);
    onOpenChat(chatId);
  };

  const handleCopyInvite = async (contact: SavedContact) => {
    const text = `Join me on FRIENDZONE! Add me with my Unique User ID: ${profile.uniqueCode}`;
    try {
      await navigator.clipboard.writeText(text);
      setActionBanner(`Invite message for ${contact.name} copied to clipboard.`);
    } catch {
      setActionBanner(`Share your ID ${profile.uniqueCode} with ${contact.name}.`);
    }
  };

  return (
    <div className="h-full overflow-y-auto p-4 sm:p-6 lg:p-8">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex items-start gap-3">
            {onBack && (
              <button
                type="button"
                onClick={onBack}
                className="mt-0.5 w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0"
                aria-label="Back"
                title="Back"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            )}
            <div>
              <h1 className="font-display text-2xl font-bold text-slate-900 dark:text-white">
                Add Friends
              </h1>
              <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
                Add friends by Name &amp; Phone Number, Unique User ID, or search the directory.
              </p>
            </div>
          </div>

          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-4 py-3 flex items-center gap-3">
            <div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">Your Unique User ID</p>
              <p className="font-mono text-sm font-semibold text-slate-900 dark:text-white">
                {profile.uniqueCode}
              </p>
            </div>
            <button
              type="button"
              onClick={handleCopyMyCode}
              className="px-3 py-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 text-xs font-medium inline-flex items-center gap-1.5 hover:bg-indigo-100 dark:hover:bg-indigo-900/50"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
        </div>

        {actionBanner && (
          <div className="rounded-xl bg-indigo-50 dark:bg-indigo-950/50 border border-indigo-200 dark:border-indigo-900 px-4 py-3 text-sm text-indigo-800 dark:text-indigo-300 flex items-center justify-between">
            <span>{actionBanner}</span>
            <button type="button" onClick={() => setActionBanner(null)} className="p-1">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Add Friend by Name & Number + Lookup by Unique ID */}
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Add by Name & Phone Number */}
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 sm:p-6">
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
              Add Friend by Name &amp; Number
            </h2>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Enter your friend’s name and phone number to connect or save them to your contacts.
            </p>

            <form onSubmit={handleAddByNameAndPhone} className="mt-4 space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Friend’s Name
                </label>
                <div className="relative">
                  <UserIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    maxLength={80}
                    value={friendName}
                    onChange={(e) => setFriendName(e.target.value)}
                    placeholder="e.g., Maya Lin"
                    className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 pl-10 pr-4 py-2.5 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[44px]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Phone Number
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="tel"
                    required
                    maxLength={24}
                    value={friendPhone}
                    onChange={(e) => setFriendPhone(e.target.value)}
                    placeholder="e.g., +14155550142"
                    className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 pl-10 pr-4 py-2.5 text-sm font-mono text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[44px]"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={addingByPhone}
                className="w-full rounded-xl fz-gradient px-5 py-2.5 text-sm font-semibold text-white hover:opacity-95 disabled:opacity-50 transition-opacity min-h-[44px] inline-flex items-center justify-center gap-2"
              >
                <UserPlus className="w-4 h-4" />
                <span>{addingByPhone ? 'Searching & Adding...' : 'Add Friend'}</span>
              </button>
            </form>

            {phoneErrorMsg && (
              <p className="mt-3 text-xs text-rose-600 dark:text-rose-400">{phoneErrorMsg}</p>
            )}

            {phoneResultMsg && (
              <div className="mt-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 p-3 text-xs text-emerald-800 dark:text-emerald-300 leading-relaxed">
                {phoneResultMsg}
              </div>
            )}

            {nameCandidates.length > 0 && (
              <div className="mt-3 space-y-2">
                <p className="text-xs font-medium text-slate-700 dark:text-slate-300">
                  Matching profiles by name:
                </p>
                {nameCandidates.slice(0, 4).map((cand) => {
                  const link = getFriendshipWith(cand.uid);
                  return (
                    <div
                      key={cand.uid}
                      className="rounded-xl border border-slate-200 dark:border-slate-800 p-3 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <Avatar src={cand.photoURL} name={cand.displayName} size="sm" />
                        <div className="min-w-0">
                          <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                            {cand.displayName}
                          </p>
                          <p className="text-[11px] font-mono text-slate-400 truncate">
                            {cand.uniqueCode}
                          </p>
                        </div>
                      </div>
                      {link?.status === 'accepted' ? (
                        <button
                          type="button"
                          onClick={() => handleStartChat(cand.uid)}
                          className="px-3 py-1.5 rounded-lg fz-gradient text-white text-xs font-medium shrink-0"
                        >
                          Message
                        </button>
                      ) : link?.status === 'pending' ? (
                        <span className="text-xs text-slate-400">Pending</span>
                      ) : (
                        <button
                          type="button"
                          onClick={() => handleSendRequest(cand)}
                          className="px-3 py-1.5 rounded-lg fz-gradient text-white text-xs font-medium shrink-0"
                        >
                          Send Request
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Exact Lookup by Unique User ID */}
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 sm:p-6 flex flex-col justify-between">
            <div>
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                Find by Unique User ID
              </h2>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Paste a friend’s FRIENDZONE ID code (e.g., <span className="font-mono">FZ-MAYA2026</span>) to send a direct request.
              </p>

              <form onSubmit={handleLookupCode} className="mt-4 flex flex-col sm:flex-row gap-3">
                <input
                  type="text"
                  value={codeInput}
                  onChange={(e) => setCodeInput(e.target.value)}
                  placeholder="Enter Unique User ID (FZ-...)"
                  className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-4 py-2.5 text-sm font-mono uppercase text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[44px]"
                />
                <button
                  type="submit"
                  className="rounded-xl fz-gradient px-5 py-2.5 text-sm font-semibold text-white hover:opacity-95 transition-opacity min-h-[44px] whitespace-nowrap"
                >
                  Look Up ID
                </button>
              </form>

              {codeError && (
                <p className="mt-3 text-xs text-rose-600 dark:text-rose-400">{codeError}</p>
              )}

              {codeResult && (
                <div className="mt-4 rounded-xl border border-slate-200 dark:border-slate-800 p-4 flex items-center justify-between gap-4 bg-slate-50 dark:bg-slate-800/40">
                  <div className="flex items-center gap-3 min-w-0">
                    <Avatar src={codeResult.photoURL} name={codeResult.displayName} isOnline={codeResult.isOnline} showPresence />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-slate-900 dark:text-white truncate">
                        {codeResult.displayName}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                        {codeResult.uniqueCode} · {codeResult.bio || 'FRIENDZONE member'}
                      </p>
                    </div>
                  </div>
                  {getFriendshipWith(codeResult.uid)?.status === 'accepted' ? (
                    <button
                      type="button"
                      onClick={() => handleStartChat(codeResult.uid)}
                      className="px-4 py-2 rounded-xl fz-gradient text-white text-xs font-semibold shrink-0"
                    >
                      Message
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => handleSendRequest(codeResult)}
                      className="px-4 py-2 rounded-xl fz-gradient text-white text-xs font-semibold shrink-0 inline-flex items-center gap-1.5"
                    >
                      <UserPlus className="w-3.5 h-3.5" />
                      <span>Add Friend</span>
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Saved Phone Contacts Preview */}
            {savedContacts.length > 0 && (
              <div className="mt-6 pt-4 border-t border-slate-200 dark:border-slate-800">
                <h3 className="text-xs font-semibold text-slate-700 dark:text-slate-300 tabular-nums">
                  Saved Phone Contacts ({savedContacts.length})
                </h3>
                <div className="mt-2 divide-y divide-slate-100 dark:divide-slate-800 max-h-44 overflow-y-auto">
                  {savedContacts.map((c) => (
                    <div key={c.id} className="py-2.5 flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-xs font-medium text-slate-900 dark:text-white truncate">
                          {c.name}
                        </p>
                        <p className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                          {c.phoneNumber}
                        </p>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        {c.linkedUid && getFriendshipWith(c.linkedUid)?.status === 'accepted' ? (
                          <button
                            type="button"
                            onClick={() => handleStartChat(c.linkedUid)}
                            className="px-2.5 py-1 rounded-lg fz-gradient text-white text-[11px] font-medium"
                          >
                            Chat
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleCopyInvite(c)}
                            className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 text-[11px] font-medium text-slate-600 dark:text-slate-300"
                          >
                            Copy Invite
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => deleteSavedContact(profile.uid, c.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600"
                          title="Delete contact"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </section>

        {/* Incoming & Outgoing Friend Requests */}
        {(incomingRequests.length > 0 || outgoingRequests.length > 0) && (
          <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 sm:p-6">
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white tabular-nums">
                Incoming Requests ({incomingRequests.length})
              </h2>
              {incomingRequests.length === 0 ? (
                <p className="mt-3 text-xs text-slate-500 dark:text-slate-400">
                  No pending incoming requests.
                </p>
              ) : (
                <div className="mt-4 divide-y divide-slate-100 dark:divide-slate-800">
                  {incomingRequests.map((req) => {
                    const sender = usersById[req.requesterId];
                    return (
                      <div key={req.id} className="py-3 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3 min-w-0">
                          <Avatar src={sender?.photoURL} name={sender?.displayName || 'User'} />
                          <div className="min-w-0">
                            <p className="text-sm font-medium text-slate-900 dark:text-white truncate">
                              {sender?.displayName || req.requesterId}
                            </p>
                            <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                              {sender?.uniqueCode || ''}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => respondFriendRequest(req, profile, 'accepted')}
                            className="px-3 py-1.5 rounded-lg fz-gradient text-white text-xs font-medium"
                          >
                            Accept
                          </button>
                          <button
                            type="button"
                            onClick={() => respondFriendRequest(req, profile, 'declined')}
                            className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-600 dark:text-slate-300"
                          >
                            Decline
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 sm:p-6">
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white tabular-nums">
                Sent Requests ({outgoingRequests.length})
              </h2>
              {outgoingRequests.length === 0 ? (
                <p className="mt-3 text-xs text-slate-500 dark:text-slate-400">
                  No outgoing pending requests.
                </p>
              ) : (
                <div className="mt-4 divide-y divide-slate-100 dark:divide-slate-800">
                  {outgoingRequests.map((req) => {
                    const rec = usersById[req.recipientId];
                    return (
                      <div key={req.id} className="py-3 flex items-center justify-between gap-3">
                        <div className="flex items-center gap-3 min-w-0">
                          <Avatar src={rec?.photoURL} name={rec?.displayName || 'User'} />
                          <div className="min-w-0">
                            <p className="text-sm font-medium text-slate-900 dark:text-white truncate">
                              {rec?.displayName || req.recipientId}
                            </p>
                            <p className="text-xs text-slate-500 dark:text-slate-400">Pending approval</p>
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeFriendship(req.id)}
                          className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
                        >
                          Cancel
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </section>
        )}

        {/* Current Friends List & Directory Search */}
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* My Friends */}
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 sm:p-6">
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white tabular-nums">
              My Friends ({friends.length})
            </h2>
            {friends.length === 0 ? (
              <p className="mt-4 text-sm text-slate-500 dark:text-slate-400">
                You have not added any friends yet.
              </p>
            ) : (
              <div className="mt-4 divide-y divide-slate-100 dark:divide-slate-800">
                {friends.map((friend) => {
                  const link = getFriendshipWith(friend.uid);
                  return (
                    <div key={friend.uid} className="py-3 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3 min-w-0">
                        <Avatar
                          src={friend.photoURL}
                          name={friend.displayName}
                          isOnline={friend.isOnline}
                          showPresence
                        />
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-slate-900 dark:text-white truncate">
                            {friend.displayName}
                          </p>
                          <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                            {friend.isOnline ? 'Online' : 'Offline'} · <span className="font-mono">{friend.uniqueCode}</span>
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleStartChat(friend.uid)}
                          className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/40"
                          title="Message"
                        >
                          <MessageCircle className="w-4 h-4" />
                        </button>
                        {link && (
                          <button
                            type="button"
                            onClick={() => removeFriendship(link.id)}
                            className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-400 hover:text-rose-600 hover:bg-slate-50 dark:hover:bg-slate-800"
                            title="Remove friend"
                          >
                            <UserMinus className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Search People Directory */}
          <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 sm:p-6">
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
              Search People
            </h2>
            <div className="mt-3 relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by name, bio, or ID..."
                className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 pl-10 pr-4 py-2.5 text-sm text-slate-900 dark:text-white"
              />
            </div>

            <div className="mt-4 divide-y divide-slate-100 dark:divide-slate-800 max-h-96 overflow-y-auto">
              {loadingSearch ? (
                <p className="py-4 text-xs text-slate-500 dark:text-slate-400">Searching directory...</p>
              ) : directoryUsers.length === 0 ? (
                <p className="py-4 text-xs text-slate-500 dark:text-slate-400">
                  No matching users found.
                </p>
              ) : (
                directoryUsers.map((u) => {
                  const link = getFriendshipWith(u.uid);
                  return (
                    <div key={u.uid} className="py-3 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3 min-w-0">
                        <Avatar src={u.photoURL} name={u.displayName} isOnline={u.isOnline} showPresence />
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-slate-900 dark:text-white truncate">
                            {u.displayName}
                          </p>
                          <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                            <span className="font-mono">{u.uniqueCode}</span> · {u.bio || 'FRIENDZONE member'}
                          </p>
                        </div>
                      </div>

                      {link?.status === 'accepted' ? (
                        <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-600 dark:text-emerald-400 shrink-0">
                          <UserCheck className="w-3.5 h-3.5" />
                          <span>Friends</span>
                        </span>
                      ) : link?.status === 'pending' ? (
                        <span className="text-xs text-slate-400 shrink-0">Pending</span>
                      ) : (
                        <button
                          type="button"
                          onClick={() => handleSendRequest(u)}
                          className="px-3 py-1.5 rounded-lg fz-gradient text-white text-xs font-medium shrink-0 inline-flex items-center gap-1.5"
                        >
                          <UserPlus className="w-3.5 h-3.5" />
                          <span>Add</span>
                        </button>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};
