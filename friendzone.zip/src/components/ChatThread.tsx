import React, { useEffect, useRef, useState } from 'react';
import {
  FileText,
  Flag,
  Image as ImageIcon,
  Paperclip,
  Reply,
  Send,
  Trash2,
  X,
} from 'lucide-react';
import { uploadMediaFile } from '../lib/firebase';
import { formatDateDivider, formatMessageTime, sanitizeUrl } from '../lib/utils';
import { submitReport } from '../services/chatService';
import { ChatMessage, UserProfile } from '../types';
import { Avatar } from './Avatar';

interface ChatThreadProps {
  messages: ChatMessage[];
  currentUser: UserProfile;
  isGroupChat?: boolean;
  canDeleteAny?: boolean;
  storageFolder: string;
  maxFileSizeMB?: number;
  reportContextPrefix: string;
  onSendMessage: (payload: {
    text: string;
    mediaURL?: string;
    mediaType?: 'none' | 'image' | 'file';
    fileName?: string;
    replyTo?: ChatMessage | null;
  }) => Promise<void>;
  onDeleteMessage: (messageId: string) => Promise<void>;
}

export const ChatThread: React.FC<ChatThreadProps> = ({
  messages,
  currentUser,
  isGroupChat = false,
  canDeleteAny = false,
  storageFolder,
  maxFileSizeMB = 10,
  reportContextPrefix,
  onSendMessage,
  onDeleteMessage,
}) => {
  const [text, setText] = useState('');
  const [replyTo, setReplyTo] = useState<ChatMessage | null>(null);
  const [uploading, setUploading] = useState(false);
  const [sending, setSending] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [pendingMedia, setPendingMedia] = useState<{
    url: string;
    fileName: string;
    isImage: boolean;
  } | null>(null);
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);
  const [reportingMsg, setReportingMsg] = useState<ChatMessage | null>(null);
  const [reportReason, setReportReason] = useState('');
  const [reportStatus, setReportStatus] = useState<string | null>(null);

  const bottomRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setUploadError(null);
    setUploading(true);
    try {
      const result = await uploadMediaFile(storageFolder, file, maxFileSizeMB);
      setPendingMedia(result);
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'File upload failed.');
    } finally {
      setUploading(false);
    }
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!text.trim() && !pendingMedia) || sending) return;
    setSending(true);
    setUploadError(null);
    try {
      await onSendMessage({
        text: text.trim(),
        mediaURL: pendingMedia?.url || '',
        mediaType: pendingMedia ? (pendingMedia.isImage ? 'image' : 'file') : 'none',
        fileName: pendingMedia?.fileName || '',
        replyTo,
      });
      setText('');
      setPendingMedia(null);
      setReplyTo(null);
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Failed to send message.');
    } finally {
      setSending(false);
    }
  };

  const handleReportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reportingMsg || !reportReason.trim()) return;
    await submitReport({
      reporter: currentUser,
      targetType: 'message',
      targetId: `${reportContextPrefix}/${reportingMsg.id}`,
      targetLabel: `Message by ${reportingMsg.senderName}`,
      reason: reportReason.trim(),
    });
    setReportingMsg(null);
    setReportReason('');
    setReportStatus('Report submitted to moderators.');
    setTimeout(() => setReportStatus(null), 3500);
  };

  let lastDateLabel = '';

  return (
    <div className="flex flex-col h-full min-h-0">
      {/* Message List */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-6 py-4 space-y-3 bg-slate-50/70 dark:bg-slate-950/60">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center py-12">
            <p className="font-display font-semibold text-slate-700 dark:text-slate-200">
              No messages yet
            </p>
            <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
              Say hello or share an image to start the conversation.
            </p>
          </div>
        ) : (
          messages.map((msg) => {
            const isMine = msg.senderId === currentUser.uid;
            const dateLabel = formatDateDivider(msg.createdAt);
            const showDate = dateLabel && dateLabel !== lastDateLabel;
            if (dateLabel) lastDateLabel = dateLabel;
            const safeMediaUrl = sanitizeUrl(msg.mediaURL);

            return (
              <React.Fragment key={msg.id}>
                {showDate && (
                  <div className="flex justify-center py-2">
                    <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-3 py-1 rounded-full">
                      {dateLabel}
                    </span>
                  </div>
                )}

                <div className={`group flex items-end gap-2 ${isMine ? 'justify-end' : 'justify-start'}`}>
                  {!isMine && isGroupChat && (
                    <Avatar src={msg.senderPhoto} name={msg.senderName} size="sm" />
                  )}

                  <div className={`max-w-[78%] sm:max-w-[68%] flex flex-col ${isMine ? 'items-end' : 'items-start'}`}>
                    {!isMine && isGroupChat && (
                      <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1 px-1">
                        {msg.senderName}
                      </span>
                    )}

                    <div
                      className={`relative rounded-2xl px-4 py-2.5 text-sm leading-relaxed break-words ${
                        msg.deleted
                          ? 'bg-slate-100 dark:bg-slate-800/70 text-slate-400 dark:text-slate-500 italic border border-slate-200 dark:border-slate-800'
                          : isMine
                            ? 'fz-gradient text-white rounded-br-md shadow-sm'
                            : 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-800 rounded-bl-md'
                      }`}
                    >
                      {/* Quoted Reply */}
                      {!msg.deleted && msg.replyToId && (
                        <div
                          className={`mb-2 rounded-xl px-3 py-1.5 text-xs ${
                            isMine
                              ? 'bg-white/15 text-white/90'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          <p className="font-semibold">{msg.replyToSender}</p>
                          <p className="truncate opacity-90">{msg.replyToText || 'Attachment'}</p>
                        </div>
                      )}

                      {/* Media Attachment */}
                      {!msg.deleted && safeMediaUrl && msg.mediaType === 'image' && (
                        <button
                          type="button"
                          onClick={() => setLightboxImage(safeMediaUrl)}
                          className="block mb-2 rounded-xl overflow-hidden max-w-xs focus:outline-none"
                        >
                          <img
                            src={safeMediaUrl}
                            alt={msg.fileName || 'Shared image'}
                            referrerPolicy="no-referrer"
                            className="max-h-64 w-auto object-cover rounded-xl"
                          />
                        </button>
                      )}

                      {!msg.deleted && safeMediaUrl && msg.mediaType === 'file' && (
                        <a
                          href={safeMediaUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className={`mb-2 flex items-center gap-2 rounded-xl px-3 py-2 text-xs font-medium ${
                            isMine
                              ? 'bg-white/15 text-white hover:bg-white/25'
                              : 'bg-slate-100 dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 hover:bg-slate-200 dark:hover:bg-slate-700'
                          }`}
                        >
                          <FileText className="w-4 h-4 shrink-0" />
                          <span className="truncate max-w-[200px]">{msg.fileName || 'Download file'}</span>
                        </a>
                      )}

                      {msg.text && <p className="whitespace-pre-wrap">{msg.text}</p>}

                      <div
                        className={`mt-1 flex items-center justify-end gap-2 text-[10px] font-mono tabular-nums ${
                          msg.deleted
                            ? 'text-slate-400'
                            : isMine
                              ? 'text-white/75'
                              : 'text-slate-400 dark:text-slate-500'
                        }`}
                      >
                        <span>{formatMessageTime(msg.createdAt)}</span>
                      </div>
                    </div>

                    {/* Message Quick Actions */}
                    {!msg.deleted && (
                      <div className="mt-1 flex items-center gap-1 opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity">
                        <button
                          type="button"
                          onClick={() => setReplyTo(msg)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-slate-200/60 dark:hover:bg-slate-800"
                          title="Reply"
                        >
                          <Reply className="w-3.5 h-3.5" />
                        </button>
                        {(isMine || canDeleteAny) && (
                          <button
                            type="button"
                            onClick={() => onDeleteMessage(msg.id)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-slate-200/60 dark:hover:bg-slate-800"
                            title="Delete message"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                        {!isMine && (
                          <button
                            type="button"
                            onClick={() => setReportingMsg(msg)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 dark:hover:text-amber-400 hover:bg-slate-200/60 dark:hover:bg-slate-800"
                            title="Report message"
                          >
                            <Flag className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </React.Fragment>
            );
          })
        )}
        <div ref={bottomRef} />
      </div>

      {/* Feedback Notices */}
      {uploadError && (
        <div className="px-4 py-2 bg-rose-50 dark:bg-rose-950/60 border-t border-rose-200 dark:border-rose-800 text-xs text-rose-700 dark:text-rose-300 flex items-center justify-between gap-2">
          <span>{uploadError}</span>
          <button type="button" onClick={() => setUploadError(null)} className="p-1">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {reportStatus && (
        <div className="px-4 py-2 bg-emerald-50 dark:bg-emerald-950/60 border-t border-emerald-200 dark:border-emerald-800 text-xs text-emerald-700 dark:text-emerald-300">
          {reportStatus}
        </div>
      )}

      {/* Reply Preview Banner */}
      {replyTo && (
        <div className="px-4 py-2 bg-indigo-50/80 dark:bg-indigo-950/40 border-t border-indigo-200 dark:border-indigo-900 flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-semibold text-indigo-700 dark:text-indigo-300">
              Replying to {replyTo.senderName}
            </p>
            <p className="text-xs text-slate-600 dark:text-slate-300 truncate">
              {replyTo.text || replyTo.fileName || 'Attachment'}
            </p>
          </div>
          <button
            type="button"
            onClick={() => setReplyTo(null)}
            className="p-1.5 rounded-lg text-slate-500 hover:bg-white/60 dark:hover:bg-slate-800"
            aria-label="Cancel reply"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Pending Media Attachment Preview */}
      {pendingMedia && (
        <div className="px-4 py-2.5 bg-slate-100 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            {pendingMedia.isImage ? (
              <img
                src={pendingMedia.url}
                alt={pendingMedia.fileName}
                className="w-12 h-12 rounded-lg object-cover border border-slate-200 dark:border-slate-700"
              />
            ) : (
              <div className="w-10 h-10 rounded-lg bg-indigo-100 dark:bg-indigo-900/40 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
                <FileText className="w-5 h-5" />
              </div>
            )}
            <div className="min-w-0">
              <p className="text-xs font-medium text-slate-900 dark:text-white truncate">
                {pendingMedia.fileName}
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">Ready to send</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setPendingMedia(null)}
            className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-200 dark:hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Message Composer */}
      <form
        onSubmit={handleSend}
        className="p-3 sm:p-4 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2"
      >
        <input
          ref={imageInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          className="hidden"
        />
        <input
          ref={fileInputRef}
          type="file"
          onChange={handleFileChange}
          className="hidden"
        />

        <button
          type="button"
          disabled={uploading}
          onClick={() => imageInputRef.current?.click()}
          className="w-11 h-11 rounded-xl flex items-center justify-center text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors shrink-0"
          title="Share image"
        >
          <ImageIcon className="w-5 h-5" />
        </button>

        <button
          type="button"
          disabled={uploading}
          onClick={() => fileInputRef.current?.click()}
          className="w-11 h-11 rounded-xl flex items-center justify-center text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors shrink-0"
          title="Attach file"
        >
          <Paperclip className="w-5 h-5" />
        </button>

        <input
          type="text"
          maxLength={4000}
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={uploading ? 'Uploading attachment...' : 'Write a message...'}
          className="flex-1 min-w-0 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-4 py-2.5 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 min-h-[44px]"
        />

        <button
          type="submit"
          disabled={sending || uploading || (!text.trim() && !pendingMedia)}
          className="w-11 h-11 rounded-xl fz-gradient text-white flex items-center justify-center shadow-sm hover:opacity-95 disabled:opacity-40 transition-opacity shrink-0"
          aria-label="Send message"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>

      {/* Image Lightbox */}
      {lightboxImage && (
        <div
          onClick={() => setLightboxImage(null)}
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
        >
          <button
            type="button"
            onClick={() => setLightboxImage(null)}
            className="absolute top-4 right-4 p-2 rounded-full bg-white/10 text-white hover:bg-white/20"
            aria-label="Close preview"
          >
            <X className="w-6 h-6" />
          </button>
          <img
            src={lightboxImage}
            alt="Full preview"
            className="max-w-full max-h-[85vh] rounded-2xl object-contain"
          />
        </div>
      )}

      {/* Report Modal */}
      {reportingMsg && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleReportSubmit}
            className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-xl"
          >
            <h3 className="font-display text-lg font-semibold text-slate-900 dark:text-white">
              Report Message
            </h3>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Reported content is reviewed by FRIENDZONE administrators.
            </p>
            <textarea
              required
              rows={3}
              maxLength={500}
              value={reportReason}
              onChange={(e) => setReportReason(e.target.value)}
              placeholder="Describe why this message violates community guidelines..."
              className="mt-4 w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 p-3 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <div className="mt-4 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setReportingMsg(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-sm font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-amber-600 text-white text-sm font-medium hover:bg-amber-700"
              >
                Submit Report
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
