import { Timestamp } from 'firebase/firestore';

export const DEMO_ASSETS = {
  heroConnect: '/src/assets/images/friendzone_hero_connect_1795736184175.jpg',
  avatarMaya: '/src/assets/images/avatar_maya_lin_1795736185247.jpg',
  avatarMarcus: '/src/assets/images/avatar_marcus_vance_1795736185154.jpg',
  groupWeekendCreators: '/src/assets/images/group_weekend_creators_1795736185054.jpg',
} as const;

export const SUPER_ADMIN_UID = 'k065aG6QXceoL5mj6QoLEHrAbR13';

export function generateUniqueCode(uid: string): string {
  const clean = uid.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
  const prefix = clean.slice(0, 4).padEnd(4, 'X');
  const suffix = clean.slice(-4).padStart(4, '0');
  return `FZ-${prefix}${suffix}`;
}

export function getDeterministicPairId(uidA: string, uidB: string): string {
  return [uidA, uidB].sort().join('_');
}

export function normalizePhoneNumber(raw: string): string {
  return raw.replace(/[^0-9]/g, '').slice(0, 20);
}

export function sanitizeString(value: string, maxLen: number): string {
  return value.trim().slice(0, maxLen);
}

export function sanitizeUrl(url: string): string {
  const trimmed = url.trim();
  if (!trimmed) return '';
  if (trimmed.startsWith('/src/assets/')) return trimmed;
  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol === 'https:' || parsed.protocol === 'http:') {
      return trimmed.slice(0, 2048);
    }
    return '';
  } catch {
    return '';
  }
}

export function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return '?';
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

export function formatMessageTime(ts: Timestamp | null | undefined): string {
  if (!ts) return '';
  const date = ts.toDate();
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

export function formatRelativeTime(ts: Timestamp | null | undefined): string {
  if (!ts) return '';
  const date = ts.toDate();
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  if (diffMin < 1) return 'Just now';
  if (diffMin < 60) return `${diffMin}m`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h`;
  const diffDays = Math.floor(diffHr / 24);
  if (diffDays < 7) return `${diffDays}d`;
  return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
}

export function formatDateDivider(ts: Timestamp | null | undefined): string {
  if (!ts) return '';
  const date = ts.toDate();
  const today = new Date();
  const yesterday = new Date();
  yesterday.setDate(today.getDate() - 1);

  if (date.toDateString() === today.toDateString()) return 'Today';
  if (date.toDateString() === yesterday.toDateString()) return 'Yesterday';
  return date.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });
}
