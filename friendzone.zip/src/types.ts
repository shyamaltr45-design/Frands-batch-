import { Timestamp } from 'firebase/firestore';

export type PageRoute =
  | 'home'
  | 'chats'
  | 'groups'
  | 'friends'
  | 'notifications'
  | 'profile'
  | 'settings'
  | 'admin';

export const VALID_ID_REGEX = /^[a-zA-Z0-9_-]+$/;
export const VALID_UNIQUE_CODE_REGEX = /^[A-Z0-9-]+$/;

export const LIMITS = {
  NAME_MAX: 80,
  BIO_MAX: 280,
  MESSAGE_MAX: 4000,
  GROUP_NAME_MAX: 80,
  GROUP_DESC_MAX: 400,
  REPORT_REASON_MAX: 500,
  BANNER_MAX: 300,
  URL_MAX: 2048,
} as const;

export interface UserProfile {
  uid: string;
  uniqueCode: string;
  displayName: string;
  photoURL: string;
  bio: string;
  isOnline: boolean;
  lastSeen: Timestamp | null;
  isBlocked: boolean;
  isDemo: boolean;
  createdAt: Timestamp | null;
  updatedAt: Timestamp | null;
}

export interface UserPrivate {
  uid: string;
  email: string;
  phoneNumber?: string;
  fcmToken: string;
  notificationsEnabled: boolean;
  themePreference: 'light' | 'dark' | 'system';
  updatedAt: Timestamp | null;
}

export interface SavedContact {
  id: string;
  name: string;
  phoneNumber: string;
  normalizedPhone: string;
  linkedUid: string;
  createdAt: Timestamp | null;
  updatedAt: Timestamp | null;
}

export interface Friendship {
  id: string;
  users: string[];
  requesterId: string;
  recipientId: string;
  status: 'pending' | 'accepted' | 'declined';
  createdAt: Timestamp | null;
  updatedAt: Timestamp | null;
}

export interface DirectChat {
  id: string;
  participantA: string;
  participantB: string;
  participants: string[];
  unreadA: number;
  unreadB: number;
  lastMessage: string;
  lastMessageAt: Timestamp | null;
  lastSenderId: string;
  createdAt: Timestamp | null;
  updatedAt: Timestamp | null;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderPhoto: string;
  text: string;
  mediaURL: string;
  mediaType: 'none' | 'image' | 'file';
  fileName: string;
  replyToId: string;
  replyToText: string;
  replyToSender: string;
  deleted: boolean;
  createdAt: Timestamp | null;
  updatedAt: Timestamp | null;
}

export interface Group {
  id: string;
  name: string;
  description: string;
  photoURL: string;
  createdBy: string;
  memberCount: number;
  lastMessage: string;
  lastMessageAt: Timestamp | null;
  lastSenderName: string;
  createdAt: Timestamp | null;
  updatedAt: Timestamp | null;
}

export interface GroupMember {
  uid: string;
  displayName: string;
  photoURL: string;
  role: 'admin' | 'member';
  joinedAt: Timestamp | null;
}

export interface UserGroupSummary {
  groupId: string;
  name: string;
  photoURL: string;
  role: 'admin' | 'member';
  lastReadAt: Timestamp | null;
  joinedAt: Timestamp | null;
}

export interface NotificationItem {
  id: string;
  recipientId: string;
  senderId: string;
  senderName: string;
  type: 'friend_request' | 'friend_accepted' | 'group_invite' | 'direct_message' | 'group_message' | 'system';
  title: string;
  body: string;
  targetType: 'chat' | 'group' | 'friends' | 'none';
  targetId: string;
  read: boolean;
  createdAt: Timestamp | null;
}

export interface ReportItem {
  id: string;
  reporterId: string;
  reporterName: string;
  targetType: 'user' | 'group' | 'message';
  targetId: string;
  targetLabel: string;
  reason: string;
  status: 'open' | 'resolved' | 'dismissed';
  createdAt: Timestamp | null;
  updatedAt: Timestamp | null;
}

export interface AppSettings {
  allowRegistration: boolean;
  allowGroupCreation: boolean;
  maxGroupSize: number;
  maxFileSizeMB: number;
  maintenanceMode: boolean;
  announcementBanner: string;
  updatedAt: Timestamp | null;
  updatedBy: string;
}

export interface AdminRecord {
  uid: string;
  email: string;
  role: 'super_admin' | 'admin';
  addedBy: string;
  createdAt: Timestamp | null;
}
